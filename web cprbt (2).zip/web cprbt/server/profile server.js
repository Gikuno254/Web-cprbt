// server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000; // Choose a port for your backend

// Connect to MongoDB (replace 'your_database_url' with your MongoDB connection string)
mongoose.connect('your_database_url', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a simple user model (you can adjust this based on your MongoDB schema)
const User = mongoose.model('User', {
  name: String,
  email: String,
  // Add other fields as needed
});

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Serve static files (e.g., HTML, CSS, JS)
app.use(express.static('public')); // Assuming your frontend files are in the 'public' directory

// API endpoint to get user profile details
app.get('/api/profile', async (req, res) => {
  try {
    // Fetch user profile from the database (replace with your logic)
    const user = await User.findOne({ /* your query here */ });

    // Send user profile as JSON response
    res.json(user);
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
