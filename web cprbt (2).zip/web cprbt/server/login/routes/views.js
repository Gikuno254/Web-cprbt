// routes/views.js

const express = require('express');
const viewController = require('../controllers/viewController');
const validateResetToken = require('../middlewares/validateResetToken');

const router = express.Router();

// Existing routes...
router.get('/reset-password/:resetToken', validateResetToken, viewController.getResetPassword);

// Existing routes...
router.get('/reset-password', viewController.getResetPassword);

module.exports = router;
