const express = require('express');
const router = express.Router();
const { resetController } = require('../controllers/reset');

router.post('/submit', resetController);

module.exports = router;
