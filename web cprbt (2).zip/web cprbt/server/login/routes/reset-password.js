const express = require('express');
const router = express.Router();
const resetPasswordController = require('../controllers/reset-password');

router.post('/submit', resetPasswordController.submitResetPassword);

module.exports = router;
