const express = require('express');
const router = express.Router();
const sendEmail = require('../utils/sendEmail');
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');
const { validateLogin, validateReset } = require('../middleware/validationMiddleware');

// Mocked user data (replace with your database logic)
const users = [
  { id: 1, firstName: 'John', lastName: 'Doe', email: 'john@example.com', password: 'hashed_password' },
  // Add more users as needed
];


router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password', authController.resetPassword);

router.post('/login', validateLogin, authController.login);
router.post('/reset', validateReset, authController.resetPassword);

// Login route
router.post('/login', authController.login);
router.post('/reset-password', authController.resetPassword);

// Login route
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Check credentials (replace with your actual authentication logic)
  const user = users.find(u => u.email === email && u.password === password);

  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  // You might want to use tokens for authentication in a real-world scenario
  return res.json({ message: 'Login successful', user });
});

// Password reset route
router.post('/reset-password', (req, res) => {
  const { email } = req.body;

  // Check if the email exists in your database
  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Send password reset email (replace with your logic)
  const resetText = 'Click the link to reset your password: http://yourwebsite.com/reset-password';
  sendEmail(user.email, 'Password Reset', resetText);

  return res.json({ message: 'Password reset email sent' });
});

module.exports = router;


// utils/authUtils.js

const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const generateResetToken = () => {
  const resetToken = require('crypto').randomBytes(32).toString('hex');
  return resetToken;
};

module.exports = { generateResetToken };
