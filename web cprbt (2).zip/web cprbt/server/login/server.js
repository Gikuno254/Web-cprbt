// ... (previous code)
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

// ... (previous code)

// Routes
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');
const resetRoute = require('./routes/reset');

app.use('/api/register', registerRoute);
app.use('/api/login', loginRoute);
app.use('/api/reset', resetRoute);

// ... (remaining code)


app.use(bodyParser.json());
app.use(cors());

// Include your database connection here (e.g., MongoDB, MySQL)

// Routes
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');

app.use('/api/register', registerRoute);
app.use('/api/login', loginRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// Routes
const loginRoute = require('./routes/login');
app.use('/api/login', loginRoute);

// ... (previous code)

// Routes
const resetPasswordRoute = require('./routes/reset-password');
app.use('/api/reset-password', resetPasswordRoute);
