const nodemailer = require('nodemailer');

const sendEmail = async (to, subject, text) => {
  // Setup transporter (replace with your email service credentials)
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'your_email@gmail.com',
      pass: 'your_email_password',
    },
  });

  // Setup email data
  const mailOptions = {
    from: 'your_email@gmail.com',
    to,
    subject,
    text,
  };

  // Send email
  await transporter.sendMail(mailOptions);
};

// Mocked sendEmail function (replace with your actual email sending logic)

    // Implement your email sending logic here
    // For example, you can use nodemailer or any other email sending service
  
    console.log(`Email sent to: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Text: ${text}`);
  ;

module.exports = sendEmail;
