// authUtils.js

const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: Missing token' });
  }

  try {
    const decoded = jwt.verify(token, 'your-secret-key'); // Replace with your secret key
    req.userId = decoded.userId;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Unauthorized: Invalid token' });
  }
};


const generateResetToken = () => {
    // Generate a unique reset token (you can use a library like uuid)
    // Example: const resetToken = uuid();
    const resetToken = 'unique_reset_token'; // Replace with your actual implementation
    return resetToken;
  };
module.exports = { verifyToken };
