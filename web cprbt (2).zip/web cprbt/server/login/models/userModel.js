// models/userModel.js

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  // Existing schema fields...

  resetToken: String,
  resetTokenExpiration: Date,
});

const User = mongoose.model('User', userSchema);

module.exports = User;
