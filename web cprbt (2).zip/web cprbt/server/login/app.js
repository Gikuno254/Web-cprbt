// Import required modules

const authRoutes = require('./routes/auth');
// app.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const routes = require('./routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
// Existing imports...
const authRoutes = require('./routes/auth');

// Existing imports...
const viewRoutes = require('./routes/views');

// Existing middleware setup...
app.use('/', viewRoutes);

// Existing middleware setup...
app.use('/api/auth', authRoutes);


// app.js (or your entry file)

// Existing imports...
const viewRoutes = require('./routes/views');

// Existing middleware setup...
app.use('/', viewRoutes);

// Existing error handling middleware...


// app.js (or your entry file)

// Existing imports...
const authRoutes = require('./routes/authRoutes');

// Existing middleware setup...
app.use('/api/auth', authRoutes);

// Existing error handling middleware...


// Middleware
app.use(bodyParser.json());
app.use(cors());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/goldway', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Routes
app.use('/api', routes);

// Error handler middleware
app.use(errorHandler);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


//run terminal
//node app.js
//run npm to install dependencies.
//run node app.js to start server.

