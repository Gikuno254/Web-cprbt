// authController.js


// authController.js

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const sendEmail = require('../utils/sendEmail');
const User = require('../models/User');

const register = async (req, res, next) => {
  try {
    const { firstName, lastName, email, phoneNumber, password } = req.body;

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user in the database
    const user = await User.create({
      firstName,
      lastName,
      email,
      phoneNumber,
      password: hashedPassword,
    });

    // Generate a token
    const token = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '1h' });

    // Send verification email (replace with actual verification link)
    const verificationLink = `http://localhost:3000/auth/verify-email/${token}`;
    const emailSubject = 'Verify Your Email';
    const emailText = `Click on the link to verify your email: ${verificationLink}`;
    sendEmail(email, emailSubject, emailText);

    res.status(201).json({ message: 'User registered successfully. Please check your email to verify your account.' });
  } catch (error) {
    next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Find the user in the database
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check if the password is correct
    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Generate a token
    const token = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '1h' });

    res.status(200).json({ token, message: 'Login successful. Welcome to Goldway Wealth Investment Company!' });
  } catch (error) {
    next(error);
  }
};


// Return the token and user information
res.status(200).json({
    token,
    user: {
      id: user._id,
      email: user.email,
      // Include other user information as needed
    },
  });
 catch (error) {
  next(error);
}
;

module.exports = {
  register,
  login,
};


// Mocked user data (replace with your database logic)
const users = [
    { id: 1, firstName: 'John', lastName: 'Doe', email: 'john@example.com', password: 'hashed_password' },
    // Add more users as needed
  ];
  
  
    // Check credentials (replace with your actual authentication logic)
    const user = users.find(u => u.email === email && u.password === password);
  
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
  
    // You might want to use tokens for authentication in a real-world scenario
    return res.json({ message: 'Login successful', user });
  ;
  
  // Controller for password reset
  const resetPassword = (req, res) => {
    const { email } = req.body;

     // Example: Dummy logic, replace with your actual implementation
     const { email } = req.body;

     if (!email) {
         return res.status(400).json({ error: 'Email is required' });
     }
 
     // Generate a reset token and send a reset email (replace with actual implementation)
     const resetToken = 'dummyResetToken';
 
     // In a real-world scenario, you would send an email with a link containing the resetToken
     // Here, we're simulating the reset link
     const resetLink = `http://yourwebsite.com/reset-password/${resetToken}`;
 
     return res.json({ resetLink });
 };
 
  
    // Check if the email exists in your database
    const user = users.find(u => u.email === email);
  
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
  
    // Send password reset email (replace with your logic)
    // Mocked sendEmail function
    const sendEmail = require('../utils/sendEmail');
    const resetText = 'Click the link to reset your password: http://yourwebsite.com/reset-password';
    sendEmail(user.email, 'Password Reset', resetText);
  
    return res.json({ message: 'Password reset email sent' });
  };

  res.status(200).json({ message: 'Password reset email sent successfully' });
} catch (error) {
  next(error);
}
  
  module.exports = {
    login,
    resetPassword,
  };
  

  // authController.js

const forgotPassword = async (req, res, next) => {
    try {
      const { email } = req.body;
  
      // Find the user in the database
      const user = await User.findOne({ email });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      // Generate a token for password reset
      const resetToken = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '10m' });
  
      // Save the reset token in the user's document
      user.resetToken = resetToken;
      user.resetTokenExpiration = Date.now() + 10 * 60 * 1000; // 10 minutes
      await user.save();
  
      // Send password reset email (replace with actual reset link)
      const resetLink = `http://localhost:3000/auth/reset-password/${resetToken}`;
      const emailSubject = 'Password Reset';
      const emailText = `Click on the link to reset your password: ${resetLink}`;
      sendEmail(email, emailSubject, emailText);
  
      res.status(200).json({ message: 'Password reset email sent. Please check your email to reset your password.' });
    } catch (error) {
      next(error);
    }
  };
  
  const resetPassword = async (req, res, next) => {
    try {
      const { token, newPassword } = req.body;
  
      // Find the user with the reset token
      const user = await User.findOne({ resetToken: token, resetTokenExpiration: { $gt: Date.now() } });
  
      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired token' });
      }
  
      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);
  
      // Update the user's password
      user.password = hashedPassword;
      user.resetToken = undefined;
      user.resetTokenExpiration = undefined;
      await user.save();
  
      res.status(200).json({ message: 'Password reset successful. You can now login with your new password.' });
    } catch (error) {
      next(error);
    }
  };
  
  module.exports = {
    register,
    login,
    forgotPassword,
    resetPassword,
  };
  

  // controllers/authController.js

const User = require('../models/userModel');
const { generateResetToken } = require('../utils/authUtils');

const resetPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const resetToken = generateResetToken();
    user.resetToken = resetToken;
    user.resetTokenExpiration = new Date(Date.now() + 3600000); // Token expires in 1 hour
    await user.save();

    // Send a password reset email (implement this functionality based on your email service)
    // Example: emailService.sendPasswordResetEmail(user.email, resetToken);

    res.status(200).json({ message: 'Password reset email sent successfully' });
  } catch (error) {
    next(error);
  }
};


  // Example: Dummy logic, replace with your actual implementation
  const { email, resetToken } = req.body;

  if (!email || !resetToken) {
      return res.status(400).json({ error: 'Email and reset token are required' });
  }

  // Validate the reset token (replace with actual implementation)
  if (resetToken !== 'dummyResetToken') {
      return res.status(401).json({ error: 'Invalid or expired reset token' });
  }

  // Update the user's password in the database (replace with actual implementation)
  // You may use a library like bcrypt to hash and store the new password securely
  const newPassword = 'newSecurePassword';
  
  // Dummy logic to simulate updating the password
  // In a real-world scenario, update the user's password in the database
  console.log(`Updating password for user with email: ${email} to: ${newPassword}`);

  return res.json({ message: 'Password reset successful' });
};


module.exports = { login, resetPassword };
