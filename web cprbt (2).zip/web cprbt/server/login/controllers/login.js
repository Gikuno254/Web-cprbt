const bcrypt = require('bcrypt');
const User = require('../models/user');

const loginController = {
    submitLogin: async (req, res) => {
        try {
            const { email, password } = req.body;

            // Check if the email exists
            const user = await User.findOne({ email });
            if (!user) {
                return res.status(400).json({ success: false, message: 'Invalid email or password.' });
            }

            // Check if the password is correct
            const passwordMatch = await bcrypt.compare(password, user.password);
            if (!passwordMatch) {
                return res.status(400).json({ success: false, message: 'Invalid email or password.' });
            }

            // Check if the email is verified
            if (user.status !== 'verified') {
                return res.status(400).json({ success: false, message: 'Email not verified. Please check your email for verification instructions.' });
            }

            res.json({ success: true, message: 'Login successful.' });
        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ success: false, message: 'Internal server error.' });
        }
    },
};

module.exports = loginController;
