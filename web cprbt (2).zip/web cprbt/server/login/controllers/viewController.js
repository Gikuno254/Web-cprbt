// controllers/viewController.js

const getResetPassword = (req, res) => {
    // Render the reset password view
    res.render('resetPassword', { title: 'Reset Password' });
  };
  
  module.exports = { getResetPassword };
  