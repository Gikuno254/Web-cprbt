const bcrypt = require('bcrypt');
const User = require('../models/user');
const nodemailer = require('nodemailer');

const resetPasswordController = {
    submitResetPassword: async (req, res) => {
        try {
            const { email } = req.body;

            // Check if the email exists
            const user = await User.findOne({ email });
            if (!user) {
                return res.status(400).json({ success: false, message: 'Email not found.' });
            }

            // Generate a new password
            const newPassword = Math.random().toString(36).slice(-8);

            // Hash the new password
            const hashedPassword = await bcrypt.hash(newPassword, 10);

            // Update the user's password in the database
            await User.updateOne({ email }, { $set: { password: hashedPassword } });

            // Send the new password via email
            const mailOptions = {
                from: 'your_email@gmail.com',
                to: email,
                subject: 'Goldway Limited - Password Reset',
                text: `Your new password is: ${newPassword}`,
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Error sending email:', error);
                } else {
                    console.log('Email sent:', info.response);
                }
            });

            res.json({ success: true, message: 'Password reset successful. Check your email for the new password.' });
        } catch (error) {
            console.error('Password reset error:', error);
            res.status(500).json({ success: false, message: 'Internal server error.' });
        }
    },
};

module.exports = resetPasswordController;
