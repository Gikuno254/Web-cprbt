// middlewares/validateResetToken.js

const validateResetToken = (req, res, next) => {
    // Implement logic to validate the reset token
    // Check if the reset token is valid and not expired

    // Example: Dummy logic, replace with your actual implementation
    const { resetToken } = req.params;

    if (resetToken !== 'dummyResetToken') {
        return res.status(401).json({ error: 'Invalid or expired reset token' });
    }

    // The reset token is valid
    next();
};

module.exports = validateResetToken;
