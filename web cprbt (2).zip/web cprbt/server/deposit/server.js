// Example backend route handling deposit form submission
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Handle deposit form submission
app.post('/deposit', (req, res) => {
    const { name, amount } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Send a response to the frontend
    res.json({ success: true, message: 'Deposit request submitted successfully' });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Update your existing backend route handling deposit form submission
app.post('/deposit', (req, res) => {
    const { name, amount, confirmationCode, transactionStatus } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Check if the transaction status is "completed" to prevent reversal
    if (transactionStatus === 'completed') {
        // Store the confirmation code in a database or perform necessary actions
        // Return a response to the frontend
        res.json({ success: true, message: 'Deposit successful!' });
    } else {
        // Return a response indicating the need for confirmation code verification
        res.json({ success: false, message: 'Confirmation code verification required.' });
    }
});


const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Mock deposit history data (you should replace this with a database)
let depositHistory = [];

// Handle deposit form submission
app.post('/deposit', (req, res) => {
  const { name, amount, mpesaCode } = req.body;

  // Perform any necessary backend processing here
  // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

  // Add the deposit entry to the deposit history
  const timestamp = new Date().toLocaleString();
  depositHistory.push({ name, amount, mpesaCode, timestamp });

  // Send a response to the frontend
  res.json({ success: true, message: 'Deposit request submitted successfully' });
});

// Handle deposit history fetch request
app.get('/deposit-history', (req, res) => {
  // Send the deposit history to the frontend
  res.json({ success: true, depositHistory });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Other existing backend code...

// Handle deposit history fetch request
app.get('/deposit-history', (req, res) => {
    // Send the deposit history to the frontend
    res.json({ success: true, depositHistory });
});


// Other existing backend code...

// Deposit history storage
const depositHistory = [];

// Handle deposit form submission
app.post('/deposit', (req, res) => {
    const { name, amount, mpesaCode } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Add the deposit entry to the history
    const timestamp = new Date().toLocaleString();
    depositHistory.push({ name, amount, mpesaCode, timestamp });

    // Send a response to the frontend
    res.json({ success: true, message: 'Deposit request submitted successfully' });
});

// Handle deposit history fetch request
app.get('/deposit-history', (req, res) => {
    // Send the deposit history to the frontend
    res.json({ success: true, depositHistory });
});


const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Example database to store deposit history
const depositHistory = [];

app.use(bodyParser.json());

// Handle deposit form submission
app.post('/deposit', (req, res) => {
    const { name, amount, clientPhoneNumber } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Add the deposit to the history
    const deposit = {
        name,
        amount,
        clientPhoneNumber,
        time: new Date(),
        mpesaCode: generateMpesaCode(), // Assuming you have a function to generate a unique code
    };
    depositHistory.push(deposit);

    // Send a response to the frontend
    res.json({ success: true, message: 'Deposit request submitted successfully', mpesaCode: deposit.mpesaCode });
});

// Endpoint to get deposit history
app.get('/deposit-history', (req, res) => {
    res.json(depositHistory);
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Function to generate a unique MPESA code (you can customize this)
function generateMpesaCode() {
    return Math.floor(1000 + Math.random() * 9000);
}


// Example backend route handling deposit confirmation
app.post('/confirm-deposit', (req, res) => {
    const { confirmationCode } = req.body;

    // Perform verification logic here (compare with stored code, update balance, etc.)

    // Send a response to the frontend
    res.json({ success: true, message: 'Deposit confirmed successfully' });
});

// Other existing backend code...

// Deposit history storage
const depositHistory = [];

// Handle deposit form submission
app.post('/deposit', (req, res) => {
    const { name, amount, mpesaCode } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Add the deposit entry to the history
    const timestamp = new Date().toLocaleString();
    depositHistory.push({ name, amount, mpesaCode, timestamp });

    // Send a response to the frontend
    res.json({ success: true, message: 'Deposit request submitted successfully' });
});

// Handle deposit history fetch request
app.get('/deposit-history', (req, res) => {
    // Send the deposit history to the frontend
    res.json({ success: true, depositHistory });
});


