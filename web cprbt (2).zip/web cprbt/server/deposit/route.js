const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const User = require('./models/User'); // Import your User model

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Connect to MongoDB (adjust the connection string)
mongoose.connect('mongodb://localhost:27017/your-database', { useNewUrlParser: true, useUnifiedTopology: true });

// Handle deposit confirmation
app.post('/confirm-deposit', async (req, res) => {
    const { confirmationCode } = req.body;

    try {
        // Find the user by confirmation code
        const user = await User.findOne({ confirmationCode });

        if (!user) {
            return res.status(404).json({ success: false, message: 'Invalid confirmation code' });
        }

        // Update the user's account balance
        user.balance += user.pendingDeposit;
        user.pendingDeposit = 0;
        user.confirmationCode = '';

        // Save the updated user
        await user.save();

        // Send a response to the frontend
        return res.json({ success: true, message: 'Deposit confirmed successfully' });
    } catch (error) {
        console.error('Error confirming deposit:', error);
        return res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
