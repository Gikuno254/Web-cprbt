//testing
//npm install --save-dev jest supertest



{
    "testEnvironment": "node",
    "verbose": true,
    "testMatch": ["**/tests/**/*.test.js"]
  }
  