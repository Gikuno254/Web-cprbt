//basic crud operations

const User = require('../models/user');

exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const Transaction = require('../models/transaction');

exports.updateUserBalance = async (req, res) => {
  try {
    const { userId } = req.params;
    const { amount, type } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    user.walletBalance += amount;

    // Record the transaction in the user's history
    const transaction = await Transaction.create({ userId, type, amount });
    user.transactionHistory.push(transaction);

    await user.save();

    res.json({ message: 'Wallet balance updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.calculateDailyIncome = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const currentDate = new Date();
    const lastIncomeDate = new Date(user.lastIncomeDate);

    // Calculate days since last income
    const daysSinceLastIncome = Math.floor((currentDate - lastIncomeDate) / (1000 * 60 * 60 * 24));

    // Example: Daily income of $10 for each level of investment
    const dailyIncome = 10 * user.walletBalance;

    // Calculate total daily income
    const totalDailyIncome = daysSinceLastIncome * dailyIncome;

    user.walletBalance += totalDailyIncome;
    user.lastIncomeDate = currentDate;

    await user.save();

    res.json({ message: 'Daily income calculated and added to wallet balance' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// investment transactions
exports.invest = async (req, res) => {
  try {
    const { userId } = req.params;
    const { amount, level } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.walletBalance < amount) {
      return res.status(400).json({ error: 'Insufficient funds for investment' });
    }

    // Record the investment transaction
    const transaction = await Transaction.create({
      userId,
      type: 'investment',
      amount,
      investmentDetails: { level },
    });

    user.walletBalance -= amount;
    user.transactionHistory.push(transaction);

    await user.save();

    res.json({ message: 'Investment successful' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.invest = async (req, res) => {
  try {
    // ... (existing code)

    // Send a notification
    sendNotification(user._id, 'Investment Successful', 'Your investment was successful.');

    res.json({ message: 'Investment successful' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.calculateDailyIncome = async (req, res) => {
  try {
    // ... (existing code)

    // Send a notification
    sendNotification(user._id, 'Daily Income Calculated', 'Your daily income has been added to your wallet.');

    res.json({ message: 'Daily income calculated and added to wallet balance' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const sendNotification = (userId, title, message) => {
  // Placeholder: Send notification logic (e.g., push notification, email, etc.)
  console.log(`Notification sent to user ${userId}: ${title} - ${message}`);
};
