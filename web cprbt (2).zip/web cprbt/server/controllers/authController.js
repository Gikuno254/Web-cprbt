// instal.....npm install jsonwebtoken.....library


const User = require('../models/user');
const jwt = require('jsonwebtoken');

exports.registerUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    const token = generateToken(user._id);
    const { sendConfirmationEmail } = require('../utils/email');
    // Generate a confirmation code (you can use a library like 'crypto' for this)
    const confirmationCode = 'your-generated-confirmation-code';

    // Send confirmation email
    sendConfirmationEmail(req.body.email, confirmationCode);
    res.status(201).json({ user, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.loginUser = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username, password });

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user._id);
    res.json({ user, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const generateToken = (userId) => {
  return jwt.sign({ userId }, 'your-secret-key', { expiresIn: '1h' });
};

