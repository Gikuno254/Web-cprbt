const express = require('express');
const connectDB = require('./utils/dbConnection');
const clientRoutes = require('./routes/clientRoutes');
const investmentRoutes = require('./routes/investRoutes');

const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());

// Routes
app.use('/clients', clientRoutes);
app.use('/investments', investmentRoutes);

// Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
