const Investment = require('../models/Investment');

const validateInvestment = async (req, res, next) => {
  const { level } = req.body;

  try {
    const investment = await Investment.findOne({ level });

    if (!investment) {
      return res.status(404).json({ success: false, message: 'Investment level not found' });
    }

    req.investment = investment;
    next();
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

module.exports = validateInvestment;
