const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

// Connect to MongoDB (replace 'your-mongodb-connection-string' with your actual MongoDB connection string)
mongoose.connect('your-mongodb-connection-string', { useNewUrlParser: true, useUnifiedTopology: true });

// Create a mongoose schema for investments
const investmentSchema = new mongoose.Schema({
    level: String,
    price: Number,
    dailyIncome: Number,
    totalIncome: Number,
});

// Create a mongoose model for investments
const Investment = mongoose.model('Investment', investmentSchema);

// Create a mongoose schema for clients
const clientSchema = new mongoose.Schema({
    username: String,
    accountId: String,
    accountBalance: Number,
    investments: [investmentSchema],
});

// Create a mongoose model for clients
const Client = mongoose.model('Client', clientSchema);

// Middleware
app.use(bodyParser.json());

/ Example middleware for logging incoming requests
app.use((req, res, next) => {
    console.log(`Incoming request: ${req.method} ${req.url}`);
    next();
});

// Routes
app.use('/api', investRoutes);


// Placeholder for the client database
const clients = [
    { clientId: '123', username: 'john_doe', accountBalance: 100000, investmentHistory: [] },
    // Add more clients as needed
];

// Middleware to fetch client information based on client ID
function getClientInfo(req, res, next) {
    const clientId = req.params.clientId;
    const client = clients.find(c => c.clientId === clientId);

    if (!client) {
        return res.status(404).json({ success: false, message: 'Client not found' });
    }

    req.client = client;
    next();
}

// Endpoint to fetch client information
app.get('/api/clientInfo/:clientId', getClientInfo, (req, res) => {
    const { clientId, username, accountBalance } = req.client;
    res.json({ success: true, client: { clientId, username, accountBalance } });
});

// Endpoint to handle investment completion
app.post('/api/completeInvestment/:clientId', getClientInfo, (req, res) => {
    const { clientId } = req.client;
    const { totalInvestment } = req.body;

    // Placeholder for backend logic to process the investment and update the database
    // You need to implement server-side logic to handle the investment completion
    // For simplicity, we'll simulate the update here
    const success = simulateInvestmentUpdate(clientId, totalInvestment);

    if (success) {
        res.json({ success: true, message: 'Investment completed successfully' });
    } else {
        res.status(500).json({ success: false, message: 'Failed to complete the investment' });
    }
});

// Function to simulate the backend logic for investment completion
function simulateInvestmentUpdate(clientId, amount) {
    const client = clients.find(c => c.clientId === clientId);

    if (!client) {
        return false;
    }

    // Simulate updating the client's account balance and investment history
    client.accountBalance -= amount;
    client.investmentHistory.push({ amount, date: new Date() });

    return true;
}

// Endpoint to fetch client information
app.get('/api/clientInfo', (req, res) => {
    // Placeholder for fetching client information from the database
    // You need to implement server-side logic to retrieve the client's details
    // For simplicity, we'll simulate the client information here
    const client = {
        clientId: '123',
        username: 'john_doe',
        accountBalance: 100000,
    };

    res.json({ success: true, client });
});

// Fetch investment data endpoint
app.get('/api/investments', async (req, res) => {
    try {
        const investments = {
            vip: await Investment.find({ level: { $regex: 'VIP' } }),
            superLev: await Investment.find({ level: { $regex: 'Super Lev' } }),
            goldWay: await Investment.find({ level: { $regex: 'Goldway' } }),
        };

        res.json({ success: true, investments });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// Fetch client data endpoint
app.get('/api/clients/:accountId', async (req, res) => {
    try {
        const client = await Client.findOne({ accountId: req.params.accountId });

        if (client) {
            res.json({ success: true, client });
        } else {
            res.status(404).json({ success: false, message: 'Client not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// Create a new investment endpoint
app.post('/api/invest', async (req, res) => {
    try {
        const { accountId, level } = req.body;

        // Fetch the selected investment level
        const investment = await Investment.findOne({ level });

        if (!investment) {
            res.status(404).json({ success: false, message: 'Investment level not found' });
            return;
        }

        // Fetch the client
        const client = await Client.findOne({ accountId });

        if (!client) {
            res.status(404).json({ success: false, message: 'Client not found' });
            return;
        }

        // Check if the client has enough funds
        if (client.accountBalance < investment.price) {
            res.status(400).json({ success: false, message: 'Insufficient funds' });
            return;
        }

        // Deduct the investment amount from the account balance
        client.accountBalance -= investment.price;

        // Add the investment to the client's investments array
        client.investments.push({
            level: investment.level,
            price: investment.price,
            dailyIncome: investment.dailyIncome,
            totalIncome: investment.totalIncome,
        });

        // Save the updated client information
        await client.save();

        res.json({ success: true, message: 'Investment successful' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// ... (Add more backend routes as needed)
// Endpoint to handle deposit
app.post('/api/deposit/:clientId', getClientInfo, (req, res) => {
    const { clientId } = req.client;
    const { depositAmount } = req.body;

    // Placeholder for backend logic to process the deposit and update the database
    // You need to implement server-side logic to handle the deposit
    // For simplicity, we'll simulate the update here
    const success = simulateDeposit(clientId, depositAmount);

    if (success) {
        res.json({ success: true, message: 'Deposit successful' });
    } else {
        res.status(500).json({ success: false, message: 'Failed to deposit funds' });
    }
});

// Function to simulate the backend logic for deposit
function simulateDeposit(clientId, amount) {
    const client = clients.find(c => c.clientId === clientId);

    if (!client) {
        return false;
    }

    // Simulate updating the client's account balance
    client.accountBalance += amount;

    return true;
}

// Existing code ...

// Define MongoDB schema and model for investments
const investmentSchema = new mongoose.Schema({
    level: String,
    amount: Number,
    date: { type: Date, default: Date.now },
});

const Investment = mongoose.model('Investment', investmentSchema);

// API route to handle investment creation
app.post('/api/invest', async (req, res) => {
    try {
        const { level, amount } = req.body;

        // Placeholder for account balance check (you need to implement this)
        const currentBalance = 100000; // Replace with actual account balance retrieval logic

        if (amount > currentBalance) {
            return res.status(400).json({ success: false, message: 'Insufficient funds' });
        }

        // Deduct the investment amount from the account balance (you need to implement this)
        // Placeholder for database record creation
        const newInvestment = await Investment.create({ level, amount });

        return res.status(201).json({ success: true, message: 'Investment successful', data: newInvestment });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// API route to fetch investment history
app.get('/api/investments', async (req, res) => {
    try {
        const investments = await Investment.find().sort('-date'); // Sort by date in descending order
        res.json({ success: true, data: investments });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
      

        
const historyRoute = require('./routes/history');

app.use('/api/history', historyRoute);
  
    }
});




app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});



