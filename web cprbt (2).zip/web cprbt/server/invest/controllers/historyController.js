// controllers/historyController.js

const InvestmentHistory = require('../models/InvestmentHistory');

// Controller to get investment history
exports.getInvestmentHistory = async (req, res) => {
  try {
    const history = await InvestmentHistory.find().sort({ date: -1 });
    res.json({ success: true, history });
  } catch (error) {
    console.error('Error fetching investment history:', error);
    res.json({ success: false, message: 'Error fetching investment history' });
  }
};
