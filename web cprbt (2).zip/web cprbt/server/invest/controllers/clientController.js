const Client = require('../models/Client');

const getClientById = async (req, res) => {
  const { accountId } = req.params;

  try {
    const client = await Client.findOne({ accountId });

    if (client) {
      res.json({ success: true, client });
    } else {
      res.status(404).json({ success: false, message: 'Client not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

module.exports = {
  getClientById,
};
