const Client = require('../models/Client');

const invest = async (req, res) => {
  const { accountId } = req.body;

  try {
    const client = await Client.findOne({ accountId });

    if (!client) {
      return res.status(404).json({ success: false, message: 'Client not found' });
    }

    const { investment } = req;

    // Check if the client has enough funds
    if (client.accountBalance < investment.price) {
      return res.status(400).json({ success: false, message: 'Insufficient funds' });
    }

    // Deduct the investment amount from the account balance
    client.accountBalance -= investment.price;

    // Add the investment to the client's investments array
    client.investments.push({
      level: investment.level,
      price: investment.price,
      dailyIncome: investment.dailyIncome,
      totalIncome: investment.totalIncome,
    });

    // Save the updated client information
    await client.save();

    res.json({ success: true, message: 'Investment successful' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};

module.exports = {
  invest,
};


// controllers/investController.js

// Sample investment history data (replace with MongoDB integration)
let investmentHistory = [];

// Controller to handle investment confirmation
exports.confirmInvestment = (req, res) => {
    const { level, amount } = req.body;

    // Placeholder logic (replace with MongoDB integration)
    // Ensure the client has enough funds (you might need to fetch account balance from the database)
    const accountBalance = 100000; // Placeholder for account balance (replace with actual logic)
    if (amount <= accountBalance) {
        // Simulate saving the investment to a database (replace with actual database logic)
        const investment = {
            clientID: req.user.id, // Assuming you have user authentication and can access user ID
            level,
            amount,
            dailyIncome: 0, // Placeholder for daily income (you might fetch this from your investment levels)
            date: new Date().toLocaleDateString(),
        };
        investmentHistory.push(investment);

        // Deduct the invested amount from the account balance (replace with actual logic)
        const updatedBalance = accountBalance - amount;

        return res.json({ success: true, message: 'Investment confirmed successfully', data: { updatedBalance } });
    } else {
        return res.json({ success: false, message: 'Insufficient funds. Please deposit enough funds to complete the investment.' });
    }
};

// Controller to fetch investment history
exports.getInvestmentHistory = (req, res) => {
    // Placeholder logic (replace with MongoDB integration)
    // Assuming you have user authentication and can access user ID
    const clientID = req.user.id;
    const userInvestments = investmentHistory.filter(investment => investment.clientID === clientID);

    return res.json({ success: true, data: userInvestments });
};


// controllers/investController.js

const { validationResult } = require('express-validator');
const investService = require('../services/investService');

// Controller to confirm an investment
exports.confirmInvestment = async (req, res) => {
  try {
    // Validate request body
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, message: 'Invalid request body' });
    }

    const { level, amount } = req.body;

    // Placeholder for actual logic to confirm investment
    // You should perform necessary validations and update the database accordingly
    // For now, let's assume a successful confirmation
    const confirmationResult = await investService.confirmInvestment(level, amount);

    if (confirmationResult.success) {
      return res.json({ success: true, message: 'Investment confirmed successfully' });
    } else {
      return res.json({ success: false, message: 'Failed to confirm investment' });
    }
  } catch (error) {
    console.error('Error confirming investment:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};
