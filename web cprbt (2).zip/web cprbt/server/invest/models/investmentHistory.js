// models/InvestmentHistory.js

const mongoose = require('mongoose');

const investmentHistorySchema = new mongoose.Schema({
  level: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

const InvestmentHistory = mongoose.model('InvestmentHistory', investmentHistorySchema);

module.exports = InvestmentHistory;
