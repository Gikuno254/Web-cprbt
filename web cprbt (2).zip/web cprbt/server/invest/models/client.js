const mongoose = require('mongoose');

const investmentSchema = new mongoose.Schema({
  level: String,
  price: Number,
  dailyIncome: Number,
  totalIncome: Number,
});

const clientSchema = new mongoose.Schema({
  username: String,
  accountId: String,
  accountBalance: Number,
  investments: [investmentSchema],
});

const Client = mongoose.model('Client', clientSchema);

module.exports = Client;
