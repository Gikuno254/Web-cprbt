const mongoose = require('mongoose');

const investmentSchema = new mongoose.Schema({
  level: String,
  price: Number,
  dailyIncome: Number,
  totalIncome: Number,
});

const Investment = mongoose.model('Investment', investmentSchema);

module.exports = Investment;
