// routes/api.js

const express = require('express');
const { body } = require('express-validator');
const investController = require('../controllers/investController');

const router = express.Router();

// ... (existing routes)

// Route to confirm an investment
router.post('/invest', [
  body('level').notEmpty().withMessage('Level is required'),
  body('amount').isNumeric().withMessage('Amount must be a numeric value'),
], investController.confirmInvestment);


// Route to fetch investment history
router.get('/history', historyController.getInvestmentHistory);

module.exports = router;
