// routes/history.js

const express = require('express');
const router = express.Router();
const historyController = require('../controllers/historyController');

// Route to get investment history
router.get('/', historyController.getInvestmentHistory);

module.exports = router;
