const express = require('express');
const { getClientById } = require('../controllers/clientController');
const router = express.Router();

router.get('/:accountId', getClientById);

module.exports = router;
