// routes/investRoutes.js

const express = require('express');
const router = express.Router();
const investController = require('../controllers/investController');
const authMiddleware = require('../middleware/authMiddleware');

// Route to confirm investment
router.post('/invest', authMiddleware.authenticateUser, investController.confirmInvestment);

// Route to fetch investment history
router.get('/investments', authMiddleware.authenticateUser, investController.getInvestmentHistory);

module.exports = router;
