// ... (Your existing JavaScript code)

// Function to invest
async function invest(level) {
    try {
        // Fetch client data
        const response = await fetch(`/api/clients/your-account-id`); // Replace 'your-account-id' with the actual account id
        const data = await response.json();

        if (data.success) {
            const client = data.client;

            // Fetch investment data
            const investmentsResponse = await fetch('/api/investments');
            const investmentsData = await investmentsResponse.json();

            if (investmentsData.success) {
                const investments = investmentsData.investments;

                // Find the selected investment level
                const selectedInvestment = investments[level].find(inv => inv.level === level);

                if (!selectedInvestment) {
                    alert('Invalid investment level');
                    return;
                }

                // Confirm the investment
                const confirmed = confirm(`Invest ${level} for ${selectedInvestment.price} Ksh?`);

                if (confirmed) {
                    // Perform the investment
                    const investResponse = await fetch('/api/invest', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            accountId: client.accountId,
                            level,
                        }),
                    });

                    const investData = await investResponse.json();

                    if (investData.success) {
                        alert('Investment successful!');
                        // Refresh the page or update the UI as needed
                    } else {
                        alert(`Investment failed: ${investData.message}`);
                    }
                }
            } else {
                alert('Failed to fetch investment data');
            }
        } else {
            alert(`Failed to fetch client data: ${data.message}`);
        }
    } catch (error) {
        console.error(error);
        alert('An error occurred. Please try again later.');
    }
}
