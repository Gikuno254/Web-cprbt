
// ... (existing code)

async function withdrawMoney() {
    try {
      // Collect form data
      const walletType = document.querySelector('[name="wallet"]:checked').value;
      const phoneNumber = document.querySelector('[name="address"]').value;
      const withdrawalAmount = parseFloat(document.querySelector('[name="amount"]').value);
      const password = prompt('Enter your password for verification:'); // Use a more secure method in production
  
      // Validate inputs
      if (!walletType || !phoneNumber || isNaN(withdrawalAmount) || withdrawalAmount < 300) {
        alert('Invalid input. Please check your entries.');
        return;
      }
  
      // Make API request to verify password
      const response = await fetch('/api/verifyPassword', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password }),
      });
  
      const data = await response.json();
  
      // Check if password is verified
      if (data.success) {
        // Password is correct, proceed with withdrawal
        const withdrawalResponse = await fetch('/withdraw', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            wallet: walletType,
            address: phoneNumber,
            amount: withdrawalAmount,
          }),
        });
  
        const withdrawalData = await withdrawalResponse.json();
  
        if (withdrawalData.success) {
          alert('Withdrawal successful!');
          // Additional logic if needed (e.g., updating UI, redirecting, etc.)
        } else {
          alert(`Withdrawal failed: ${withdrawalData.message}`);
        }
      } else {
        alert('Password verification failed. Please try again.');
      }

      try {
        // Send a withdrawal request to the server
        const response = await fetch('/withdraw/request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                walletType,
                phoneNumber,
                amount: withdrawalAmount,
            }),
        });

        const data = await response.json();

        if (data.success) {
            alert('Withdrawal request successful. Waiting for admin approval.');
        } else {
            alert('Withdrawal request failed. Please try again.');
        }

        
    } catch (error) {
      console.error('Error in withdrawMoney:', error);
      alert('An error occurred during withdrawal. Please try again.');
    }
  }