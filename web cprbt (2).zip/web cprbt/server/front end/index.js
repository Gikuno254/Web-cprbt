document.addEventListener("DOMContentLoaded", function () {
    // Add your existing code for the scroll-to-top button here
  });
  
  // Wallet Balance
  let walletBalance = 0;
  
  // Initial Account Balance
  let accountBalance = 0;
  
  // Update Wallet Balance Function
  function updateWallet(amount) {
    walletBalance += amount;
    document.getElementById("walletBalance").innerText = `KSH ${walletBalance}`;
  }
  
  // Update Account Balance Function
  function updateAccountBalanceDisplay() {
    document.getElementById("accountBalanceAmount").innerText = `KSH ${accountBalance}`;
  }
  
  // Deposit Functionality
  function deposit(amount) {
    accountBalance += amount;
    updateWallet(amount);
    updateAccountBalanceDisplay();
  }
  
  // Invest Functionality
  function invest(amount) {
    if (accountBalance >= amount) {
      accountBalance -= amount;
      updateWallet(-amount);
      // Additional logic for investments (e.g., record the investment, calculate daily income, etc.)
      // ...
      alert("Investment successful!");
    } else {
      alert("Insufficient funds in the account.");
    }
  }
  
  // Daily Income Functionality
  function calculateDailyIncome(level) {
    const dailyIncomePercentage = 5; // Example: 5% daily income for each level of investment
    const income = (level / 100) * dailyIncomePercentage * accountBalance;
    updateWallet(income);
    //dailly income calculation
    function calculateDailyIncome(level) {
        // Example: $10 daily income for each level of investment
        const dailyIncome = 10;
        return dailyIncome * level;
      }
      
  }
  
  // Withdraw Functionality
  function withdraw(amount) {
    if (accountBalance >= amount) {
      accountBalance -= amount;
      updateWallet(-amount);
    } else {
      alert("Insufficient funds in the account.");
    }
  }
  
  // Initiate Transaction Functionality
  function initiateTransaction() {
    const mpesaPin = prompt("Enter M-Pesa PIN:");
    if (mpesaPin !== null && mpesaPin !== "") {
      // Perform the transaction logic (connect with deposit.html)
      alert("Initiating transaction with M-Pesa PIN: " + mpesaPin);
      // Redirect to deposit.html or perform other necessary actions
    } else {
      alert("Transaction canceled or invalid M-Pesa PIN.");
    }
  }
  
  // Event listener for initiating transactions
  document.getElementById("transactionBtn").addEventListener("click", function () {
    initiateTransaction();
  });
  
  // Event listener for deposit button
  document.getElementById("depositBtn").addEventListener("click", function () {
    const depositAmount = parseFloat(prompt("Enter deposit amount (KSH):"));
    if (!isNaN(depositAmount) && depositAmount > 0) {
      deposit(depositAmount);
      alert("Deposit successful!");
    } else {
      alert("Invalid deposit amount.");
    }
  });
  
  // Event listener for exploring investment history
  document.getElementById("exploreHistoryBtn").addEventListener("click", function () {
    // Placeholder for displaying investment history details
    document.getElementById("investmentHistoryDetails").style.display = "block";
    // Retrieve and display investment history details
  });
  
  // Event listener for tracking daily income
  document.getElementById("trackIncomeBtn").addEventListener("click", function () {
    // Placeholder for displaying daily income details
    document.getElementById("dailyIncomeDetails").style.display = "block";
    // Retrieve and display daily income details
  });
  
  // Event listener for viewing account details
  document.getElementById("viewAccountBtn").addEventListener("click", function () {
    // Redirect to view account page (view_account.html or any relevant page)
    window.location.href = "view_account.html";
  });
  
  // Event listener for navigating to the invest page
  document.getElementById("investBtn").addEventListener("click", function () {
    // Redirect to the invest page (invest.html or any relevant page)
    window.location.href = "invest.html";
  });
  
  // Event listener for navigating to the transaction history page
  document.getElementById("transactionHistoryBtn").addEventListener("click", function () {
    // Redirect to the transaction history page (transaction_history.html or any relevant page)
    window.location.href = "transaction_history.html";
  });
  
  // Event listener for navigating to the withdraw history page
  document.getElementById("withdrawHistoryBtn").addEventListener("click", function () {
    // Redirect to the withdraw history page (withdraw_history.html or any relevant page)
    window.location.href = "withdraw_history.html";
  });
  


  // Assume this function is triggered when the user clicks the deposit button

  function deposit(amount) {
    const depositAmount = parseFloat(amount);
  
    if (!isNaN(depositAmount) && depositAmount > 0) {
      fetch('/api/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: depositAmount }),
      })
        .then(handleFetchError)
        .then(data => {
          // Handle success
          console.log('Deposit successful:', data);
          accountBalance = data.accountBalance;
          updateWallet(data.walletBalance);
          updateAccountBalanceDisplay();
          // Additional logic if needed
        })
        .catch(error => {
          // Handle error
          console.error('Deposit failed:', error.message);
        });
    } else {
      alert('Invalid deposit amount.');
    }
  }
  
  
  // Assume this function is triggered when the user clicks the withdraw button
function withdraw(amount) {
    const withdrawAmount = parseFloat(amount);
  
    if (!isNaN(withdrawAmount) && withdrawAmount > 0) {
      fetch('/api/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: withdrawAmount }),
      })
        .then(response => response.json())
        .then(data => {
          // Handle success
          console.log('Withdrawal successful:', data);
          // Additional logic if needed
        })
        .catch(error => {
          // Handle error
          console.error('Withdrawal failed:', error);
        });
    } else {
      alert('Invalid withdrawal amount.');
    }
  }

  
  // Assume this function is triggered when the page loads to get account information
function getAccountInformation() {
    fetch('/api/account')
      .then(response => response.json())
      .then(data => {
        // Handle success
        console.log('Account information:', data);
        // Update the UI with the received data
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch account information:', error);
      });
  }
  


  // Assume this function is triggered when the user clicks the invest button
function invest(amount) {
    const investAmount = parseFloat(amount);
  
    if (!isNaN(investAmount) && investAmount > 0) {
      fetch('/api/invest', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount: investAmount }),
      })
        .then(response => response.json())
        .then(data => {
          // Handle success
          console.log('Investment successful:', data);
          // Additional logic if needed
        })
        .catch(error => {
          // Handle error
          console.error('Investment failed:', error);
        });
    } else {
      alert('Invalid investment amount.');
    }
  }

  
  // Assume this function is triggered when the user clicks the track daily income button

  function trackDailyIncome(level) {
    fetch(`/api/daily-income?level=${level}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(handleFetchError)
      .then(data => {
        // Handle success
        console.log(`Daily income for level ${level}:`, data);
        // Update the UI with the received data (assuming you have an HTML element to display daily income)
        const incomeContainer = document.getElementById('dailyIncomeDetails');
        incomeContainer.innerHTML = `Daily Income for Level ${level}: ${data.dailyIncome}`;
        incomeContainer.style.display = 'block';
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch daily income:', error.message);
      });
  }
  

  // Assume this function is triggered when the user clicks the explore history button

  function exploreInvestmentHistory() {
    fetch('/api/investment-history', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(handleFetchError)
      .then(data => {
        // Handle success
        console.log('Investment history:', data);
        // Update the UI with the received data (assuming you have an HTML element to display history)
        const historyContainer = document.getElementById('investmentHistoryDetails');
        historyContainer.innerHTML = ''; // Clear previous data
  
        data.forEach(historyItem => {
          const listItem = document.createElement('li');
          listItem.textContent = `Amount: ${historyItem.amount}, Type: ${historyItem.type}, Time: ${historyItem.time}`;
          historyContainer.appendChild(listItem);
        });
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch investment history:', error.message);
      });
  }
  
  
  // Assume this function is triggered when the user clicks the initiate transaction button
  function initiateTransactionWithMPesa() {
    // Show loading indicator or message
    showLoadingMessage();
  
    const mpesaPin = prompt("Enter M-Pesa PIN:");
  
    if (mpesaPin !== null && mpesaPin !== "") {
      const transactionAmount = 200; // Replace with the actual transaction amount
  
      fetch('/api/initiate-mpesa-transaction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ mpesaPin, transactionAmount }),
      })
        .then(handleFetchError)
        .then(data => {
          // Handle success
          console.log('M-Pesa transaction initiated successfully:', data);
          // Hide loading indicator or message
          hideLoadingMessage();
          alert('Please check your phone for the M-Pesa prompt.');
        })
        .catch(error => {
          // Handle error
          console.error('M-Pesa transaction initiation failed:', error.message);
          // Hide loading indicator or message
          hideLoadingMessage();
          alert('Transaction failed. Please try again.');
        });
    } else {
      // Hide loading indicator or message
      hideLoadingMessage();
      alert('Transaction canceled or invalid M-Pesa PIN.');
    }
  }
  
  function showLoadingMessage() {
    // Implement UI update to show loading indicator or message
  }
  
  function hideLoadingMessage() {
    // Implement UI update to hide loading indicator or message
  }
  



  //handle fetch API responses
  function handleFetchResponse(response) {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  }
  
  
  // Assume this function is triggered when the user clicks the transaction history button
function getTransactionHistory() {
    fetch('/api/transaction-history', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(response => response.json())
      .then(data => {
        // Handle success
        console.log('Transaction history:', data);
        // Update the UI with the received data
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch transaction history:', error);
      });
  }
  

  // Assume this function is triggered when the user clicks the view account button
function getUserProfile() {
    fetch('/api/user-profile', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(response => response.json())
      .then(data => {
        // Handle success
        console.log('User profile information:', data);
        // Update the UI with the received data
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch user profile information:', error);
      });
  }

  
  // Assume this function is triggered when the user clicks the logout button
function logoutUser() {
    fetch('/api/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(response => response.json())
      .then(data => {
        // Handle success
        console.log('Logout successful:', data);
        // Redirect to the login page or perform other necessary actions
        window.location.href = '/login.html';
      })
      .catch(error => {
        // Handle error
        console.error('Logout failed:', error);
      });
  }
  

  function handleFetchError(response) {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  }
  
  // Example usage:
  fetch('/api/some-endpoint')
    .then(handleFetchError)
    .then(data => {
      // Handle success
      console.log('Data:', data);
    })
    .catch(error => {
      // Handle error
      console.error('Failed to fetch data:', error.message);
    });

    
//refactor navigation menu  navigateTo
function navigateTo(page) {
    switch (page) {
      case 'accountBalance':
        getAccountInformation();
        break;
      case 'transactionHistory':
        getTransactionHistory();
        break;
      case 'withdrawHistory':
        withdraw(500); // Example: withdraw KSH 500
        break;
      case 'investmentHistory':
        invest(1000); // Example: invest KSH 1000
        calculateDailyIncome(2); // Example: calculate daily income for level 2 investment
        exploreInvestmentHistory();
        break;
      default:
        break;
    }
  }

  //improve logout functionality
  //logoutUser
  function logoutUser() {
    fetch('/api/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(handleFetchError)
      .then(data => {
        // Handle success
        console.log('Logout successful:', data);
        // Redirect to the login page or perform other necessary actions
        window.location.href = '/login.html';
      })
      .catch(error => {
        // Handle error
        console.error('Logout failed:', error.message);
      });
  }
  
  //consistent time formatting
  function getCurrentTime() {
    const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false };
    return new Date().toLocaleDateString(undefined, options);
  }
  

  document.addEventListener("DOMContentLoaded", function () {
    // Fetch user data on page load
    fetch('/api/user-data', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(handleFetchResponse)
      .then(userData => {
        // Initialize wallet and account balance based on user data
        walletBalance = userData.walletBalance;
        accountBalance = userData.accountBalance;
  
        // Update the UI with the initial balances
        updateWallet(walletBalance);
        updateAccountBalanceDisplay();
      })
      .catch(error => {
        // Handle error
        console.error('Failed to fetch user data:', error.message);
      });
  
  });


  function handleTransactionError(error) {
  console.error('Transaction failed:', error.message);
  alert('Transaction failed. Please try again.');
}

// Example usage:
fetch('/api/perform-transaction', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({ /* transaction data */ }),
})
  .then(handleFetchResponse)
  .then(data => {
    // Handle success
    console.log('Transaction successful:', data);
    // Additional logic if needed
  })
  .catch(handleTransactionError);



  // Example function to check user authentication status on page load
document.addEventListener("DOMContentLoaded", function () {
    fetch('/api/check-auth', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(handleFetchResponse)
      .then(authData => {
        // Check if the user is authenticated
        if (authData.isAuthenticated) {
          // User is authenticated, proceed with the application
          console.log('User is authenticated.');
        } else {
          // Redirect to the login page if not authenticated
          window.location.href = '/login.html';
        }
      })
      .catch(error => {
        // Handle error
        console.error('Failed to check authentication status:', error.message);
      });
  });
  




  // Example function to initiate an investment
function initiateInvestment(userId, amount, level) {
    fetch(`/api/users/${userId}/invest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Add authentication token if available
        // 'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ amount, level }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data.message);
        // Handle success (e.g., update UI)
      })
      .catch((error) => {
        console.error('Error initiating investment:', error);
        // Handle error (e.g., display error message)
      });
  }
  
  // Example function to fetch user details
  function getUserDetails(userId) {
    fetch(`/api/users/${userId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        // Add authentication token if available
        // 'Authorization': `Bearer ${token}`
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('User details:', data);
        // Handle user details (e.g., update UI)
      })
      .catch((error) => {
        console.error('Error fetching user details:', error);
        // Handle error (e.g., display error message)
      });
  }
  
  

  //front end back end integration

  // Example usage
const userId = 'your-user-id'; // Replace with the actual user ID
const investmentAmount = 100; // Replace with the actual investment amount
const investmentLevel = 2; // Replace with the actual investment level

initiateInvestment(userId, investmentAmount, investmentLevel);
getUserDetails(userId);