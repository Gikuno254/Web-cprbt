// Existing code ...

// Function to fetch client information from the backend
async function getClientInfo() {
    try {
        const response = await fetch('/api/clientInfo'); // Adjust the API endpoint as needed
        const data = await response.json();

        if (data.success) {
            const { clientId, username, accountBalance } = data.client;
            
            // Display client information on the page
            document.getElementById('clientId').textContent = clientId;
            document.getElementById('username').textContent = username;
            document.getElementById('accountBalance').textContent = formatCurrency(accountBalance);
        } else {
            console.error('Failed to fetch client information');
        }
    } catch (error) {
        console.error('Error fetching client information:', error);
    }
}

// Function to check if the client has sufficient funds to invest
function hasSufficientFunds(amount) {
    const currentBalance = parseInt(document.getElementById('accountBalance').textContent);
    return currentBalance >= amount;
}

// Function to complete the investment
function completeInvestment() {
    const totalInvestment = parseInt(document.getElementById('totalInvestment').textContent);

    // Placeholder for backend API call to handle investment completion
    // You need to implement server-side logic to process the investment and update the database
    // For simplicity, we'll simulate the backend response here
    const success = simulateInvestment(totalInvestment);

    if (success) {
        // Clear the investment cart and update the progress bar
        document.getElementById('cartItems').innerHTML = '';
        updateProgressBar(totalInvestment);
        alert('Investment completed successfully!');
    } else {
        alert('Failed to complete the investment. Please try again.');
    }
}

// Function to simulate the backend API call for investment completion
function simulateInvestment(amount) {
    // Placeholder logic; replace with actual backend integration
    const success = confirm(`Investment completed successfully for ${formatCurrency(amount)} Ksh`);
    if (success) {
        // Placeholder for updating client information after a successful investment
        // You need to implement server-side logic to update the client's account balance, investment history, etc.
        // For simplicity, we'll simulate the update here
        const updatedBalance = simulateDeposit(-amount);
        document.getElementById('accountBalance').textContent = formatCurrency(updatedBalance);
    }
    return success;
}

// Existing code ...

// Fetch client information when the page loads
document.addEventListener('DOMContentLoaded', () => {
    getClientInfo();
    populateInvestmentTables();
});

// Existing code ...




// Function to fetch client information from the backend
async function getClientInfo() {
    try {
        const response = await fetch('/api/clientInfo/123'); // Adjust the client ID as needed
        const data = await response.json();

        if (data.success) {
            const { clientId, username, accountBalance } = data.client;
            
            // Display client information on the page
            document.getElementById('clientId').textContent = clientId;
            document.getElementById('username').textContent = username;
            document.getElementById('accountBalance').textContent = formatCurrency(accountBalance);
        } else {
            console.error('Failed to fetch client information');
        }
    } catch (error) {
        console.error('Error fetching client information:', error);
    }
}

// Function to complete the investment
async function completeInvestment() {
    const totalInvestment = parseInt(document.getElementById('totalInvestment').textContent);

    // Check if the client has sufficient funds
    if (!hasSufficientFunds(totalInvestment)) {
        alert('Insufficient funds. Please deposit enough funds to complete the investment.');
        return;
    }

    // Placeholder for backend API call to complete the investment
    // You need to implement server-side logic to handle the investment completion
    // For simplicity, we'll simulate the backend update here
    const success = await simulateCompleteInvestment(totalInvestment);

    if (success) {
        // Clear the investment cart and update the progress bar
        document.getElementById('cartItems').innerHTML = '';
        updateProgressBar(totalInvestment);
        alert('Investment completed successfully!');
    } else {
        alert('Failed to complete the investment. Please try again.');
    }
}

// Function to simulate the backend API call for completing the investment
async function simulateCompleteInvestment(amount) {
    try {
        const response = await fetch('/api/completeInvestment/123', { // Adjust the client ID as needed
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ totalInvestment: amount }),
        });

        const data = await response.json();
        return data.success;
    } catch (error) {
        console.error('Error completing investment:', error);
        return false;
    }
}

// Existing code ...

// Fetch client information when the page loads
document.addEventListener('DOMContentLoaded', () => {
    getClientInfo();
    populateInvestmentTables();
});


// Existing code ...

// Function to check if the client has sufficient funds
function hasSufficientFunds(amount) {
    const accountBalance = parseInt(document.getElementById('accountBalance').textContent);
    return accountBalance >= amount;
}

// Function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES' }).format(amount);
}

// Existing code ...

// Fetch client information when the page loads
document.addEventListener('DOMContentLoaded', () => {
    getClientInfo();
    populateInvestmentTables();
});

// Existing code ...


// Function to deposit funds
async function depositFunds() {
    const depositAmount = parseInt(document.getElementById('depositAmount').value);

    if (isNaN(depositAmount) || depositAmount <= 0) {
        alert('Please enter a valid deposit amount.');
        return;
    }

    // Placeholder for backend API call to deposit funds
    // You need to implement server-side logic to handle the deposit
    // For simplicity, we'll simulate the backend update here
    const success = await simulateDepositFunds(depositAmount);

    if (success) {
        // Fetch updated client information after deposit
        getClientInfo();
        alert(`Deposit of ${formatCurrency(depositAmount)} Ksh successful!`);
    } else {
        alert('Failed to deposit funds. Please try again.');
    }
}

// Function to simulate the backend API call for deposit
async function simulateDepositFunds(amount) {
    try {
        const response = await fetch('/api/deposit/123', { // Adjust the client ID as needed
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ depositAmount: amount }),
        });

        const data = await response.json();
        return data.success;
    } catch (error) {
        console.error('Error depositing funds:', error);
        return false;
    }
}

// Existing code ...

// Attach deposit functionality to the Deposit button
document.getElementById('depositButton').addEventListener('click', depositFunds);

// Existing code ...



// Existing code ...

// Function to calculate daily income
function calculateDailyIncome() {
    const investmentAmount = parseInt(document.getElementById('investmentAmount').value);

    if (isNaN(investmentAmount) || investmentAmount <= 0) {
        alert('Please enter a valid investment amount.');
        return;
    }

    // Placeholder for backend API call to calculate daily income
    // You need to implement server-side logic to calculate daily income based on the investment amount
    // For simplicity, we'll simulate the backend calculation here
    const dailyIncome = simulateCalculateDailyIncome(investmentAmount);

    document.getElementById('dailyIncomeDisplay').textContent = `Estimated Daily Income: ${formatCurrency(dailyIncome)} Ksh`;
}

// Function to simulate backend calculation of daily income
function simulateCalculateDailyIncome(investmentAmount) {
    // Placeholder formula (replace with your actual calculation)
    return investmentAmount * 0.05;
}

// Function to confirm investment
function confirmInvestment() {
    const investmentAmount = parseInt(document.getElementById('investmentAmount').value);

    if (isNaN(investmentAmount) || investmentAmount <= 0) {
        alert('Please enter a valid investment amount.');
        return;
    }

    // Check if the client has sufficient funds
    if (!hasSufficientFunds(investmentAmount)) {
        alert('Insufficient funds. Please deposit enough funds to complete the investment.');
        return;
    }

    // Placeholder for backend API call to confirm investment
    // You need to implement server-side logic to handle the investment confirmation
    // For simplicity, we'll simulate the backend confirmation here
    const success = simulateConfirmInvestment(investmentAmount);

    if (success) {
        alert(`Investment of ${formatCurrency(investmentAmount)} Ksh confirmed!`);
        // Update client information after investment
        getClientInfo();
        // Reset investment calculator
        document.getElementById('investmentAmount').value = '';
        document.getElementById('dailyIncomeDisplay').textContent = 'Estimated Daily Income: 0 Ksh';
    } else {
        alert('Failed to confirm investment. Please try again.');
    }
}

// Function to simulate backend confirmation of investment
function simulateConfirmInvestment(investmentAmount) {
    // Placeholder for backend logic to handle investment confirmation
    // You need to implement server-side logic to update the database and confirm the investment
    // For simplicity, we'll simulate the backend confirmation here
    return true;
}

// Existing code ...

// Attach calculate daily income and confirm investment functionality to the buttons
document.getElementById('calculateIncomeButton').addEventListener('click', calculateDailyIncome);
document.getElementById('confirmInvestmentButton').addEventListener('click', confirmInvestment);

// Existing code ...





// Existing code ...

// Function to check if the client has sufficient funds
function hasSufficientFunds(investmentAmount) {
    const accountBalance = parseInt(document.getElementById('accountBalance').textContent);
    return accountBalance >= investmentAmount;
}

// Function to update client information after investment
function getClientInfo() {
    // Placeholder for backend API call to get updated client information
    // You need to implement server-side logic to fetch and update client information
    // For simplicity, we'll simulate the backend call here
    const clientInfo = simulateGetClientInfo();

    // Update client information on the front end
    document.getElementById('clientId').textContent = `Client ID: ${clientInfo.id}`;
    document.getElementById('clientUsername').textContent = `Username: ${clientInfo.username}`;
    document.getElementById('investmentLevel').textContent = `Investment Level: ${clientInfo.investmentLevel}`;
    document.getElementById('dailyIncome').textContent = `Daily Income: ${formatCurrency(clientInfo.dailyIncome)} Ksh`;
}

// Function to simulate backend call for getting client information
function simulateGetClientInfo() {
    // Placeholder for backend logic to fetch client information
    // You need to implement server-side logic to query the database for client details
    // For simplicity, we'll simulate the backend call here
    return {
        id: 12345,
        username: 'john_doe',
        investmentLevel: 'VIP 3',
        dailyIncome: 200, // Simulated value
    };
}

// Function to simulate backend deposit for demo purposes
function simulateDeposit(amount) {
    const currentBalance = parseInt(document.getElementById('accountBalance').textContent);
    return currentBalance + amount;
}

// Existing code ...


// Existing code ...

// Function to open the deposit modal
function openDepositModal() {
    const depositModal = document.getElementById('depositModal');
    depositModal.style.display = 'block';
}

// Function to close the deposit modal
function closeDepositModal() {
    const depositModal = document.getElementById('depositModal');
    depositModal.style.display = 'none';
}

// Function to confirm deposit from the modal
function confirmDeposit() {
    const depositAmountInput = document.getElementById('depositAmountModal');
    const depositAmount = parseInt(depositAmountInput.value);

    if (isNaN(depositAmount) || depositAmount <= 0) {
        alert('Please enter a valid deposit amount.');
        return;
    }

    // Placeholder for backend API call to update account balance
    // You need to implement server-side logic to update the account balance in the database
    // For simplicity, we'll simulate an update here
    const updatedBalance = simulateDeposit(depositAmount);

    // Update account balance on the front end
    document.getElementById('accountBalance').textContent = formatCurrency(updatedBalance);

    alert(`Deposit of ${formatCurrency(depositAmount)} Ksh successful!`);
    depositAmountInput.value = '';
    closeDepositModal();
}

// Existing code ...

// Attach client information update functionality to the "Deposit Funds" button
document.getElementById('depositFundsButton').addEventListener('click', openDepositModal);

// Existing code ...


// Existing code ...

// Function to simulate backend investment history for demo purposes
function simulateInvestmentHistory() {
    // Placeholder for backend logic to fetch investment history
    // You need to implement server-side logic to query the database for investment history
    // For simplicity, we'll simulate the backend call here
    return [
        { level: 'VIP 1', amount: 800, date: '2024-03-15' },
        { level: 'Super Lev 2', amount: 3200, date: '2024-03-16' },
        { level: 'Goldway 3', amount: 3500, date: '2024-03-17' },
    ];
}

// Function to display investment history
function displayInvestmentHistory() {
    const historyContainer = document.getElementById('investmentHistory');
    historyContainer.innerHTML = ''; // Clear previous content

    const investmentHistory = simulateInvestmentHistory();

    if (investmentHistory.length === 0) {
        historyContainer.innerHTML = '<p>No investment history available.</p>';
        return;
    }

    const historyList = document.createElement('ul');
    investmentHistory.forEach(entry => {
        const listItem = document.createElement('li');
        listItem.textContent = `${entry.level}: ${formatCurrency(entry.amount)} Ksh (Date: ${entry.date})`;
        historyList.appendChild(listItem);
    });

    historyContainer.appendChild(historyList);
}

// Function to toggle the investment history section
function toggleInvestmentHistory() {
    const historyContainer = document.getElementById('investmentHistory');
    historyContainer.style.display = historyContainer.style.display === 'none' ? 'block' : 'none';
}

// Existing code ...

// Attach functionality to the "Investment History" button
document.getElementById('investmentHistoryButton').addEventListener('click', toggleInvestmentHistory);

// Display investment history on page load
document.addEventListener('DOMContentLoaded', displayInvestmentHistory);

// Existing code ...




// invest.js

// ... (existing code)

// Function to confirm investment
function confirmInvestment(investment) {
    // Placeholder for backend API call
    // You would need to implement server-side logic to handle the investment confirmation
    fetch('/api/invest', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            level: investment.level,
            amount: investment.price,
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`Investment confirmed for ${investment.level}!`);
                resetCalculator();
            } else {
                alert(`Investment failed: ${data.message}`);
            }
        })
        .catch(error => {
            console.error('Error confirming investment:', error);
            alert('An error occurred while confirming the investment.');
        });
}

// Function to fetch investment history
function fetchInvestmentHistory() {
    fetch('/api/investments')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Display investment history (you can customize this based on your layout)
                const historyContainer = document.getElementById('investmentHistory');
                historyContainer.innerHTML = ''; // Clear previous entries

                data.data.forEach(investment => {
                    const entry = document.createElement('div');
                    entry.textContent = `${investment.level}: ${formatCurrency(investment.amount)} Ksh (${investment.date})`;
                    historyContainer.appendChild(entry);
                });
            } else {
                console.error('Failed to fetch investment history:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching investment history:', error);
        });
}

// Function to reset the calculator
function resetCalculator() {
    const calculator = document.getElementById('calculator');
    calculator.style.display = 'none';
    calculator.textContent = '';

    // Fetch and display investment history after a successful investment
    fetchInvestmentHistory();
}

// ...

// Trigger fetching of investment history on page load
document.addEventListener('DOMContentLoaded', fetchInvestmentHistory);

// ... (existing code)


// invest.js

// ... (existing code)

// Function to handle investment confirmation
function confirmInvestment(investment) {
    const depositAmount = investment.price;

    // Placeholder for backend API call to confirm investment
    // Replace with actual backend URL
    const confirmInvestmentUrl = '/api/invest';
    const requestBody = {
        level: investment.level,
        amount: depositAmount,
    };

    // Make a POST request to confirm the investment
    fetch(confirmInvestmentUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Investment confirmed for ${investment.level}!`);
            // Reset the calculator after confirming the investment
            resetCalculator();
            // Fetch and display updated account balance
            fetchAccountBalance();
            // Add the investment to the cart (for display purposes)
            addToCart(investment.level, investment.price, investment.dailyIncome, investment.totalIncome);
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error confirming investment:', error);
    });
}

// Function to fetch and display investment history
function fetchInvestmentHistory() {
    // Placeholder for backend API call to fetch investment history
    // Replace with actual backend URL
    const investmentHistoryUrl = '/api/investments';

    // Make a GET request to fetch investment history
    fetch(investmentHistoryUrl)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Display investment history (you can modify this based on your UI structure)
            const historyList = document.getElementById('investmentHistory');
            historyList.innerHTML = ''; // Clear existing list
            data.data.forEach(investment => {
                const listItem = document.createElement('li');
                listItem.textContent = `Level: ${investment.level}, Amount: ${investment.amount} Ksh, Date: ${investment.date}`;
                historyList.appendChild(listItem);
            });
        } else {
            console.error('Error fetching investment history:', data.message);
        }
    })
    .catch(error => {
        console.error('Error fetching investment history:', error);
    });
}

// Function to reset the calculator
function resetCalculator() {
    const calculator = document.getElementById('calculator');
    calculator.style.display = 'none';
    calculator.textContent = '';
}

// Function to add items to the cart
function addToCart(level, price, dailyIncome, totalIncome) {
    // ... (existing code)
}

// Function to fetch and display account balance
function fetchAccountBalance() {
    // Placeholder for backend API call to fetch account balance
    // Replace with actual backend URL
    const accountBalanceUrl = '/api/account/balance';

    // Make a GET request to fetch account balance
    fetch(accountBalanceUrl)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Display account balance (you can modify this based on your UI structure)
            const accountBalanceElement = document.getElementById('accountBalance');
            accountBalanceElement.textContent = `Account Balance: ${formatCurrency(data.balance)} Ksh`;
        } else {
            console.error('Error fetching account balance:', data.message);
        }
    })
    .catch(error => {
        console.error('Error fetching account balance:', error);
    });
}

// Function to format currency (assuming it's not already available)
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES' }).format(amount);
}

// ... (existing code)

// Fetch initial account balance and investment history on page load
fetchAccountBalance();
fetchInvestmentHistory();


// public/invest.js

// ... (existing code)

document.addEventListener('DOMContentLoaded', () => {
    // Existing code...
  
    // Fetch and display investment history
    fetchInvestmentHistory();
  });
  
  // Function to fetch and display investment history
  async function fetchInvestmentHistory() {
    try {
      const response = await fetch('/api/history');
      const { success, history } = await response.json();
  
      if (success) {
        displayInvestmentHistory(history);
      } else {
        console.error('Error fetching investment history');
      }
    } catch (error) {
      console.error('Error fetching investment history:', error);
    }
  }
  
  // Function to display investment history
  function displayInvestmentHistory(history) {
    const historyContainer = document.getElementById('investmentHistory');
  
    // Clear existing content
    historyContainer.innerHTML = '';
  
    // Display investment history
    history.forEach(entry => {
      const historyItem = document.createElement('div');
      historyItem.textContent = `${entry.level} - Amount: ${entry.amount} Ksh, Date: ${new Date(entry.date).toLocaleString()}`;
      historyContainer.appendChild(historyItem);
    });
  }
  

  // public/invest.js

document.addEventListener('DOMContentLoaded', () => {
    // ... (existing code)
  
    // Fetch investment history and display it
    fetchInvestmentHistory();
  });
  
  async function fetchInvestmentHistory() {
    try {
      const response = await fetch('/api/history');
      const data = await response.json();
  
      if (data.success) {
        const historyList = document.getElementById('investmentHistoryList');
        historyList.innerHTML = ''; // Clear previous entries
  
        data.history.forEach(entry => {
          const listItem = document.createElement('li');
          listItem.textContent = `Level: ${entry.level}, Amount: ${formatCurrency(entry.amount)} Ksh, Date: ${new Date(entry.date).toLocaleDateString()}`;
          historyList.appendChild(listItem);
        });
      } else {
        console.error('Error fetching investment history:', data.message);
      }
    } catch (error) {
      console.error('Error fetching investment history:', error);
    }
  }
  