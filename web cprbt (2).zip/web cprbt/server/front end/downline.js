// downline.js

function referFriend() {
    // Get values from the form
    var friendName = document.getElementById('friendName').value;
    var friendEmail = document.getElementById('friendEmail').value;

    // AJAX request to backend for referral logic
    fetch('/refer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ friendName, friendEmail }),
    })
    .then(response => response.json())
    .then(data => {
        // Display bonuses
        alert(`Congratulations!\nYou earned Ksh ${data.clientBonus} for referring ${friendName}.\n${friendName} earned Ksh ${data.referredFriendBonus}.\nClient 2 earned Ksh ${data.client2Bonus}.`);
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
}
