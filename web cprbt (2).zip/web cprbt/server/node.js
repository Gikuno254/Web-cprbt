//mkdir your-project-name
//cd your-project-name
//npm init -y
//npm install express mongoose body-parser


//structure
- your-project-name
  - src
    - controllers
    - models
    - routes
  - app.js



  