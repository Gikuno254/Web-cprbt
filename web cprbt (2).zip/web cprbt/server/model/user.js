//user model

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  walletBalance: { type: Number, default: 0 },
  transactionHistory: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Transaction',
    },
  ],
  //last income date
  lastIncomeDate: { type: Date, default: Date.now },
});

const User = mongoose.model('User', userSchema);

module.exports = User;


const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName: String,
  secondName: String,
  email: { type: String, unique: true },
  phoneNumber: String,
  password: String,
  verified: { type: Boolean, default: false },
});

const User = mongoose.model('User', userSchema);

module.exports = User;


  
