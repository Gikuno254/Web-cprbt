// models/yourModel.js

const mongoose = require('mongoose');

const yourModelSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    amount: {
        type: Number,
        required: true,
    },
    // Add other properties as needed
});

const YourModel = mongoose.model('YourModel', yourModelSchema);

module.exports = YourModel;




//mongo DB and express
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/goldway_wealth', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;

// Check MongoDB connection
db.once('open', () => {
    console.log('Connected to MongoDB');
});

app.use(bodyParser.json());

// Deposit model schema
const depositSchema = new mongoose.Schema({
    name: { type: String, required: true },
    amount: { type: Number, required: true },
    phoneNumber: { type: String, required: true },
    confirmationCode: { type: String, required: true },
    timestamp: { type: Date, default: Date.now },
});

const Deposit = mongoose.model('Deposit', depositSchema);

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Handle deposit form submission
app.post('/deposit', async (req, res) => {
    const { name, amount, phoneNumber, confirmationCode } = req.body;

    // Perform any necessary backend processing here
    // (e.g., initiate SIM Toolkit, verify MPESA code, etc.)

    // Save deposit details to MongoDB
    const deposit = new Deposit({
        name,
        amount,
        phoneNumber,
        confirmationCode,
    });

    try {
        await deposit.save();
        // Send a response to the frontend
        res.json({ success: true, message: 'Deposit request submitted successfully' });
    } catch (error) {
        console.error(error.message);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// Retrieve deposit history
app.get('/deposit-history', async (req, res) => {
    try {
        const depositHistory = await Deposit.find().sort({ timestamp: -1 });
        res.json({ success: true, depositHistory });
    } catch (error) {
        console.error(error.message);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});



//backend.js    using express and Mong DB
const mongoose = require('mongoose');

// Define the Deposit schema
const depositSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  mpesaCode: {
    type: String,
    required: true,
  },
});

// Create the Deposit model
const Deposit = mongoose.model('Deposit', depositSchema);

module.exports = Deposit;
