//mongo DB  use url obtained by signing into  Mongo DB Atlas

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const userRoutes = require('./src/routes/userRoutes');
const liveChatRoutes = require('./routes/liveChat');
const testimonialRoutes = require('./routes/testimonials');

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB
mongoose.connect('<YOUR_DB_URI>', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.use(bodyParser.json());

// User routes
app.use('/api/users', userRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

//start server by running
//node app.js


const authRoutes = require('./src/routes/authRoutes');

app.use('/api/auth', authRoutes);


const authRoutes = require('./src/routes/authRoutes');
const userRoutes = require('./src/routes/userRoutes');

//integration with front end
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);


//connecting front to back end
const userId = 'your-user-id'; // Replace with the actual user ID
const investmentAmount = 100; // Replace with the actual investment amount
const investmentLevel = 2; // Replace with the actual investment level

initiateInvestment(userId, investmentAmount, investmentLevel);
getUserDetails(userId);

const errorHandler = require('./src/middleware/errorHandler');

// ... (existing code)

app.use(errorHandler);


//swagger documentation

const swagger = require('./src/utils/swagger');

// ... (existing code)

app.use('/api-docs', swagger.serve, swagger.setup);


// app.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const liveChatRoutes = require('./routes/liveChat');
const testimonialRoutes = require('./routes/testimonials');

const app = express();
const port = process.env.PORT || 3000;

// Connect to MongoDB (replace 'your-mongodb-uri' with your MongoDB connection string)
mongoose.connect('mongodb://localhost:27017/customerServiceDB', { useNewUrlParser: true, useUnifiedTopology: true });

// Middleware
app.use(bodyParser.json());

// Routes
app.use('/api/livechat', liveChatRoutes);
app.use('/api/testimonials', testimonialRoutes);


// Configure express-session
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
}));

// Custom middleware to check authentication before serving index.html
app.use('/index', (req, res, next) => {
  if (!req.session.loggedInUser) {
      return res.redirect('/login'); // Redirect to login if not authenticated
  }
  next();
});

// Serve index.html only to authenticated users
app.use('/index', express.static('public/index'));

// ... yo
// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
