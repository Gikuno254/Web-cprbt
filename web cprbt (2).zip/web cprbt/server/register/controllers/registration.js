const bcrypt = require('bcrypt');
const User = require('../models/user');
const validationUtils = require('../utils/validation');

const registrationController = {
    submitRegistration: async (req, res) => {
        try {
            const { firstName, secondName, email, phoneNumber, password } = req.body;

            
            // Check if the email is already registered
            const existingUser = await User.findOne({ email });
            if (existingUser) {
                return res.status(400).json({ success: false, message: 'Email is already registered.' });
            }

            // Validate password
            if (!validationUtils.validatePassword(password)) {
                return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.' });
            }

            // Hash the password
            const hashedPassword = await bcrypt.hash(password, 10);

            // Create a new user
            const newUser = new User({
                firstName,
                secondName,
                email,
                phoneNumber,
                password: hashedPassword,
            });

            // Save the user to the database
            await newUser.save();

            // Send email verification
            const verificationLink = `http://your_frontend_url/verify-email?email=${email}`;
            const mailOptions = {
                from: 'your_email@gmail.com',
                to: email,
                subject: 'Goldway Limited - Email Verification',
                text: `Click the following link to verify your email: ${verificationLink}`,
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Error sending email:', error);
                } else {
                    console.log('Email sent:', info.response);
                }
            });

            res.json({ success: true, message: 'Registration successful. Check your email for verification.' });
        } catch (error) {
            console.error('Registration error:', error);
            res.status(500).json({ success: false, message: 'Internal server error.' });
        }
    },
};

module.exports = registrationController;
