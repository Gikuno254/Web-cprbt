const express = require('express');
const router = express.Router();
const User = require('../models/user');

router.get('/verify-email', async (req, res) => {
    try {
        const { email } = req.query;

        // Update user status to 'verified' in the database
        await User.updateOne({ email }, { $set: { status: 'verified' } });

        res.send('Email verified successfully. You can now log in.');
    } catch (error) {
        console.error('Email verification error:', error);
        res.status(500).send('Internal server error during email verification.');
    }
});

module.exports = router;
