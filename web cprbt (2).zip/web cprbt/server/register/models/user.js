// Example user model, modify according to your database schema
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    firstName: String,
    secondName: String,
    email: String,
    phoneNumber: String,
    password: String,
});

const User = mongoose.model('User', userSchema);

module.exports = User;


const User = require('../models/User'); // Include your User model

// ...

const registerController = async (req, res) => {
    try {
        // Perform registration logic
        const { firstName, secondName, email, phoneNumber, password } = req.body;

        // Check if the email is unique
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ success: false, message: 'Email is already registered.' });
        }

        // Save user data to the database
        const newUser = new User({ firstName, secondName, email, phoneNumber, password });
        await newUser.save();

        // Send verification email (use nodemailer or your preferred email sending library)

        res.json({ success: true, message: 'Registration successful. Check your email for verification instructions.' });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ success: false, message: 'Internal server error.' });
    }
};

// ...
