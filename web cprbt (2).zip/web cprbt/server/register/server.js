const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000; // Choose a port number
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');
// Routes
const registrationRoute = require('./routes/registration');
const verificationRoute = require('./routes/verification');

app.use('/api/registration', registrationRoute);
app.use('/api/verification', verificationRoute);

// ... (previous code)

// Routes
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');
const resetRoute = require('./routes/reset');

app.use('/api/register', registerRoute);
app.use('/api/login', loginRoute);
app.use('/api/reset', resetRoute);

// ... (remaining code)

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/goldwaylimited', { useNewUrlParser: true, useUnifiedTopology: true });

// ... (rest of the server.js file)

// Routes
const registrationRoute = require('./routes/registration');
app.use('/api/registration', registrationRoute);

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});


// Nodemailer configuration
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your_email@gmail.com', // Replace with your email
        pass: 'your_email_password', // Replace with your email password
    },

    
});

//install npm mongoose nodemailler bcrypt


