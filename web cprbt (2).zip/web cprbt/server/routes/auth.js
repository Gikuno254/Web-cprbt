const express = require('express');
const passport = require('passport');
const bcrypt = require('bcrypt');
const { ensureAuthenticated } = require('../middlewares/auth');
const User = require('../models/User');

const router = express.Router();

// Login Page
router.get('/login', (req, res) => {
  res.render('login');
});

// Login Handle
router.post('/login', passport.authenticate('local', {
  successRedirect: '/index', // Redirect to index on successful login
  failureRedirect: '/login',
  failureFlash: true,
}));

// Register Page
router.get('/register', (req, res) => {
  res.render('register');
});

// Register Handle
router.post('/register', async (req, res) => {
  const { firstName, secondName, email, phoneNumber, password, confirmPassword } = req.body;

  // Check for password match
  if (password !== confirmPassword) {
    return res.render('register', { message: 'Passwords do not match.' });
  }

  // Check for password strength (at least 8 characters)
  if (password.length < 8) {
    return res.render('register', { message: 'Password must be at least 8 characters.' });
  }

  try {
    // Check if the email is already registered
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.render('register', { message: 'Email is already registered.' });
    }

    // Hash the password before saving to the database
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save the user to the database
    const newUser = new User({ firstName, secondName, email, phoneNumber, password: hashedPassword });
    await newUser.save();

    // Redirect to login page after successful registration
    res.redirect('/login');
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).render('error', { message: 'Internal server error.' });
  }
});

// Logout Handle
router.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/login');
});

// Index Page (Protected Route)
router.get('/index', ensureAuthenticated, (req, res) => {
  res.render('index', { user: req.user });
});

module.exports = router;
