// routes/liveChat.js

const express = require('express');
const router = express.Router();
const LiveChatMessage = require('../models/LiveChatMessage');

// Route to get all live chat messages
router.get('/messages', async (req, res) => {
    try {
        const messages = await LiveChatMessage.find().sort({ timestamp: 'asc' });
        res.json(messages);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Route to add a new live chat message
router.post('/messages', async (req, res) => {
    const message = new LiveChatMessage({
        name: req.body.name,
        message: req.body.message
    });

    try {
        const newMessage = await message.save();
        res.status(201).json(newMessage);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;
