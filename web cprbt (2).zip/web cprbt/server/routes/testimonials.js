// routes/testimonials.js

const express = require('express');
const router = express.Router();
const Testimonial = require('../models/Testimonial');

// Route to get all testimonials
router.get('/testimonials', async (req, res) => {
    try {
        const testimonials = await Testimonial.find().sort({ timestamp: 'desc' });
        res.json(testimonials);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Route to add a new testimonial
router.post('/testimonials', async (req, res) => {
    const testimonial = new Testimonial({
        name: req.body.name,
        message: req.body.message
    });

    try {
        const newTestimonial = await testimonial.save();
        res.status(201).json(newTestimonial);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;
