// utils/referralUtils.js

function generateReferralCode() {
    // Implement logic to generate a unique referral code
    // This can be a combination of letters and numbers
    // Ensure it's unique in your database
    return 'REF123';
}

module.exports = {
    generateReferralCode,
};
