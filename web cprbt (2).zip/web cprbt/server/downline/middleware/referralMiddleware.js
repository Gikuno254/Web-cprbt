// middleware/referralMiddleware.js

const User = require('../models/User');
const { generateReferralCode } = require('../utils/referralUtils');

module.exports = async function (req, res, next) {
    if (!req.user.referralCode) {
        // If user doesn't have a referral code, generate and save one
        const referralCode = generateReferralCode();
        req.user.referralCode = referralCode;
        await req.user.save();
    }

    next();
};
