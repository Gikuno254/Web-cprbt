// app.js

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const authMiddleware = require('./middleware/authMiddleware');
const referralMiddleware = require('./middleware/referralMiddleware');

dotenv.config();

const app = express();

// ... existing code ...

app.use(cors());
app.use(express.json());
app.use(authMiddleware);
app.use(referralMiddleware);

// ... existing code ...
