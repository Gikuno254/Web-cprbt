// models/User.js

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    // ... existing fields ...
    referralCode: { type: String, unique: true },
    referredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});

module.exports = mongoose.model('User', userSchema);
