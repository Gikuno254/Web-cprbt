// controllers/investController.js

const User = require('../models/User');
const { generateReferralCode } = require('../utils/referralUtils');

exports.invest = async (req, res) => {
    try {
        // ... existing code ...

        // Update the user's investment level and referral logic
        const user = await User.findById(req.user.id);

        if (user) {
            // Update user's investment level
            user.investmentLevel = investmentLevel;

            // Check if the user has a referral
            if (user.referredBy) {
                const referrer = await User.findById(user.referredBy);

                if (referrer) {
                    const commission = investmentAmount * 0.1; // 10% commission
                    referrer.accountBalance += commission;
                    await referrer.save();
                }
            }

            await user.save();
            res.status(200).json({ success: true, message: 'Investment successful.' });
        } else {
            res.status(404).json({ success: false, message: 'User not found.' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal server error.' });
    }
};
