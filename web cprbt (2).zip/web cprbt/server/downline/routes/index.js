// routes/index.js

const express = require('express');
const router = express.Router();
const investController = require('../controllers/investController');
const downlineController = require('../controllers/downlineController');

// ... existing routes ...

router.post('/refer', downlineController.referFriend);

module.exports = router;
