const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

// Connect to MongoDB (replace 'your-mongodb-uri' with your actual MongoDB URI)
mongoose.connect('your-mongodb-uri', { useNewUrlParser: true, useUnifiedTopology: true });

app.use(bodyParser.json());
app.use(cors());

// Routes
app.use('/deposit', require('./routes/deposit'));


// Define MongoDB schema for live chat messages
const liveChatSchema = new mongoose.Schema({
    name: String,
    message: String
});

// Create live chat model
const LiveChat = mongoose.model('LiveChat', liveChatSchema);

// Define MongoDB schema for customer testimonials
const testimonialSchema = new mongoose.Schema({
    name: String,
    message: String
});

// Create testimonial model
const Testimonial = mongoose.model('Testimonial', testimonialSchema);

// API endpoint for sending live chat messages
app.post('/api/livechat/messages', async (req, res) => {
    try {
        const { name, message } = req.body;
        const newMessage = new LiveChat({ name, message });
        await newMessage.save();
        res.json({ success: true, message: 'Message sent successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
});

// API endpoint for retrieving live chat messages
app.get('/api/livechat/messages', async (req, res) => {
    try {
        const messages = await LiveChat.find();
        res.json(messages);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// API endpoint for adding customer testimonials
app.post('/api/testimonials', async (req, res) => {
    try {
        const { name, message } = req.body;
        const newTestimonial = new Testimonial({ name, message });
        await newTestimonial.save();
        res.json({ success: true, message: 'Testimonial added successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
});

// API endpoint for retrieving customer testimonials
app.get('/api/testimonials', async (req, res) => {
    try {
        const testimonials = await Testimonial.find();
        res.json(testimonials);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});


const express = require('express');
const mongoose = require('mongoose');
const expressLayouts = require('express-ejs-layouts');
const passport = require('passport');
const flash = require('express-flash');
const session = require('express-session');
const authRoutes = require('./routes/auth');



// Passport Config
require('./config/passport')(passport);

// Connect to MongoDB (replace 'your_database_uri' with your actual MongoDB URI)
mongoose.connect('your_database_uri', { useNewUrlParser: true, useUnifiedTopology: true });

// EJS
app.use(expressLayouts);
app.set('view engine', 'ejs');

// Express body parser
app.use(express.urlencoded({ extended: true }));

// Express session
app.use(session({
  secret: 'your_secret_key',
  resave: true,
  saveUninitialized: true
}));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Connect flash
app.use(flash());

// Global variables for flash messages
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.user = req.user;
  next();
});

// Routes
app.use('/', authRoutes);



// Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, console.log(`Server running on port ${PORT}`));


