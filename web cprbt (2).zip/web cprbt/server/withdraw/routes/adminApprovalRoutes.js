// adminApprovalRoutes.js

const express = require('express');
const adminApprovalController = require('../controllers/adminApprovalController');
const adminApprovalMiddleware = require('../middleware/adminApprovalMiddleware');
const router = express.Router();

// Admin approval route
router.post('/approve', adminApprovalMiddleware, adminApprovalController.approveWithdrawal);

module.exports = router;
