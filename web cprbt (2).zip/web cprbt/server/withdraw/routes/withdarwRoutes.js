// routes/withdrawRoutes.js


// withdrawRoutes.js

const express = require('express');
const withdrawController = require('../controllers/withdrawController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

// Withdrawal request route
router.post('/request', authMiddleware, withdrawController.requestWithdrawal);

module.exports = router;
