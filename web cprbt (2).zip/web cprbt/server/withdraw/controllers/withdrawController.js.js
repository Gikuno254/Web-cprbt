// controllers/withdrawController.js

const Withdraw = require('../models/withdrawModel');
const User = require('../models/userModel');

// Function to handle withdrawal requests
exports.withdrawMoney = async (req, res) => {
  try {
    // Extract data from the request body
    const { isCrypto, wallet, address, amount } = req.body;

    // Validate the withdrawal amount
    if (amount < 300) {
      return res.json({ success: false, message: 'Minimum withdrawal amount is 300 KES.' });
    }

    // Fetch user details from the database
    const user = await User.findById(req.user._id);

    // Check if the user has sufficient balance
    if (user.wallet[wallet] < amount) {
      return res.json({ success: false, message: 'Insufficient funds in the selected wallet.' });
    }

    // Calculate withdrawal charges
    const withdrawalCharge = calculateWithdrawalCharge(amount);

    // Deduct the withdrawal amount and charges from the user's balance
    user.wallet[wallet] -= (amount + withdrawalCharge);
    await user.save();

    // Create a withdrawal record
    const withdrawal = new Withdraw({
      user: req.user._id,
      isCrypto,
      wallet,
      address,
      amount,
      withdrawalCharge,
    });
    await withdrawal.save();


    try {
        // Extract withdrawal data from the request body
        const { walletType, phoneNumber, amount } = req.body;

        // Calculate withdrawal fee using the utility function
        const withdrawalFee = withdrawUtils.calculateWithdrawalFee(amount);

        // Perform withdrawal logic (reduce client's account balance, etc.)
        // ...

        // Create a new withdrawal record in the database
        const newWithdrawal = new Withdraw({
            walletType,
            phoneNumber,
            amount,
            withdrawalFee,
            // Add other necessary fields
        });

        // Save the withdrawal record
        await newWithdrawal.save();

        // Send a response indicating successful withdrawal request
        res.status(200).json({ success: true, message: 'Withdrawal request submitted successfully.' });
    } catch (error) {
        // Handle errors and send an appropriate response
        console.error(error);
        res.status(500).json({ success: false, message: 'Internal server error.' });
    }
}}
    // Return success response
    return res.json({ success: true, message: 'Withdrawal successful.' });
  catch (error) {
    console.error('Error in withdrawMoney:', error);
    return res.json({ success: false, message: 'An error occurred during withdrawal.' });
  }
};

// Function to calculate withdrawal charges
const calculateWithdrawalCharge = amount => {
  let withdrawalCharge = 0;

  // Flat fee for amounts less than 300
  if (amount < 300) {
    withdrawalCharge = 10;
  } else {
    // Percentage fee for amounts greater than or equal to 300
    withdrawalCharge = amount * 0.05; // Adjust the percentage as needed
  }

  return withdrawalCharge;
};


// withdrawController.js

const Transaction = require('../models/Transaction');

const withdrawController = {
  requestWithdrawal: async (req, res) => {
    const { userId, amount } = req.body;

    try {
      // Create a pending withdrawal transaction
      const withdrawal = await Transaction.create({
        userId,
        amount,
        type: 'withdraw',
      });

      return res.json({ success: true, message: 'Withdrawal request received', withdrawal });
    } catch (error) {
      console.error(error);
      return res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },
};

module.exports = withdrawController;
