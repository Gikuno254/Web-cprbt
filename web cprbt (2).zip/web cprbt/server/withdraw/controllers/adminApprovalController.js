// adminApprovalController.js
// adminApprovalController.js

const Transaction = require('../models/Transaction');

const adminApprovalController = {
    approveWithdrawal: async (req, res) => {
        const { withdrawalId } = req.body;

        try {
            // Update the status of the withdrawal to 'approved'
            await Transaction.findByIdAndUpdate(withdrawalId, { status: 'approved' });

            // Retrieve the approved withdrawal details
            const approvedWithdrawal = await Transaction.findById(withdrawalId);

            // Assuming you have a function to process the withdrawal and update the user's account balance
            // Replace the following line with your actual logic
            // processWithdrawal(approvedWithdrawal.userId, approvedWithdrawal.amount);

            return res.json({ success: true, message: 'Withdrawal approved successfully' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
    },
};

module.exports = adminApprovalController;


// admin-approval.js

// ... (your existing JavaScript code) ...

async function approveWithdrawal(withdrawalId) {
    try {
        // Send an approval request to the server
        const response = await fetch('/admin/withdraw/approve', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer YOUR_ADMIN_ACCESS_TOKEN', // Replace with your actual admin access token
            },
            body: JSON.stringify({
                withdrawalId,
            }),
        });

        const data = await response.json();

        if (data.success) {
            alert('Withdrawal approved successfully.');
        } else {
            alert('Withdrawal approval failed. Please try again.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again later.');
    }
}
