const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Sample user data (replace this with your actual user data retrieval logic)
const users = [
  {
    username: 'sampleuser',
    password: 'samplepassword', // In a real scenario, hash passwords before storing
    // ... other user data
  },
  // Add more users as needed
];

app.use(bodyParser.json());

// Endpoint to verify the password
app.post('/api/verifyPassword', (req, res) => {
  const { password } = req.body;

  // For simplicity, let's assume a single user with a hardcoded username
  const user = users.find((u) => u.username === 'sampleuser');

  if (!user) {
    return res.json({ success: false, message: 'User not found.' });
  }

  // Check if the password matches (in a real scenario, use a secure password hashing library)
  const isPasswordCorrect = password === user.password;

  if (isPasswordCorrect) {
    return res.json({ success: true, message: 'Password verified successfully.' });
  } else {
    return res.json({ success: false, message: 'Incorrect password.' });
  }
});

// Other routes and middleware can go here

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
