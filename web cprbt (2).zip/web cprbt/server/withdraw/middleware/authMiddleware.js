// authMiddleware.js

const authMiddleware = (req, res, next) => {
    // Check if the user is authenticated (you might need to implement your authentication logic)
    const isAuthenticated = /* Your authentication logic here */;
  
    if (!isAuthenticated) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
  
    next();
  };
  
  module.exports = authMiddleware;
  