// adminApprovalMiddleware.js

const adminApprovalMiddleware = (req, res, next) => {
    // Check if the request is coming from an admin (you might need to implement your admin check logic)
    const isAdmin = /* Your admin check logic here */;
  
    if (!isAdmin) {
      return res.status(403).json({ success: false, message: 'Forbidden: Admin access required' });
    }
  
    next();
  };
  
  module.exports = adminApprovalMiddleware;
  