// app.js or server.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const withdrawRoutes = require('./routes/withdrawRoutes');
const adminApprovalRoutes = require('./routes/adminApprovalRoutes');

const app = express();
const PORT = 3000;

// Connect to MongoDB (replace 'mongodb://localhost:27017/your-database' with your actual MongoDB connection string)
mongoose.connect('mongodb://localhost:27017/your-database', { useNewUrlParser: true, useUnifiedTopology: true });

app.use(bodyParser.json());

// Use the withdrawal routes
app.use('/withdraw', withdrawRoutes);

// Use the admin approval routes
app.use('/admin/withdraw', adminApprovalRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
