// withdrawUtils.js

// Utility function to calculate withdrawal fee
const calculateWithdrawalFee = (amount) => {
    // Define your withdrawal fee logic here
    const flatFee = 10; // Flat fee for withdrawal
    const percentage = 0.01; // Percentage fee for withdrawal

    // Calculate fee based on the withdrawal amount
    const fee = amount * percentage + flatFee;

    // Return the calculated fee
    return fee;
};

// Export the utility function
module.exports = {
    calculateWithdrawalFee,
};
