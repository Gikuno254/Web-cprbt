//npm install nodemailer


const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  // Configure your email transport settings (SMTP, Gmail, etc.)
  // Example for Gmail:
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-email-password',
  },
});

exports.sendConfirmationEmail = (email, confirmationCode) => {
  const mailOptions = {
    from: 'your-email@gmail.com',
    to: email,
    subject: 'Confirm Your Email',
    text: `Click the following link to confirm your email: ${confirmationCode}`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending confirmation email:', error);
    } else {
      console.log('Confirmation email sent:', info.response);
    }
  });
};
