function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";
       
       
        // Hide sidebar after 5 seconds
        setTimeout(() => {
                hideSidebar();
            }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

 
 
 
 
 
 // Sample investment data in Ksh
 const vipInvestments = [
    { level: 'VIP 1', price: 800, dailyIncome: 56, totalIncome: 108000 },
    { level: 'VIP 2', price: 1500, dailyIncome: 90, totalIncome: 162000 },
    { level: 'VIP 3', price: 3000, dailyIncome: 180, totalIncome: 324000 },
    { level: 'VIP 4', price: 6000, dailyIncome: 360, totalIncome: 648000 },
    { level: 'VIP 5', price: 12000, dailyIncome: 610, totalIncome: 1098000 },
    { level: 'VIP 6', price: 15000, dailyIncome: 890, totalIncome: 1602000 },
  ];

  const superLevInvestments = [
    { level: 'Super Lev 1', price: 1600, dailyIncome: 84, totalIncome: 15120 },
    { level: 'Super Lev 2', price: 3200, dailyIncome: 190, totalIncome: 34200 },
    { level: 'Super Lev 3', price: 5600, dailyIncome: 265, totalIncome: 47700 },
    { level: 'Super Lev 4', price: 7300, dailyIncome: 368, totalIncome: 66240 },
    { level: 'Super Lev 5', price: 10000, dailyIncome: 550, totalIncome: 99000 },
    { level: 'Super Lev 6', price: 16000, dailyIncome: 1360, totalIncome: 244800 },
    { level: 'Super Lev 7', price: 25000, dailyIncome: 1600, totalIncome: 270000 },
    { level: 'Super Lev 8', price: 50000, dailyIncome: 3000, totalIncome: 540000 },
    { level: 'Super Lev 9', price: 80000, dailyIncome: 4500, totalIncome: 810000 },
  ];

  const goldWayInvestments = [
    { level: 'Goldway 1', price: 900, dailyIncome: 59, totalIncome: 9440 },
    { level: 'Goldway 2', price: 2000, dailyIncome: 104, totalIncome: 16640 },
    { level: 'Goldway 3', price: 3500, dailyIncome: 180, totalIncome: 28800 },
    { level: 'Goldway 4', price: 5000, dailyIncome: 340, totalIncome: 54400 },
    { level: 'Goldway 5', price: 12000, dailyIncome: 690, totalIncome: 110400 },
    { level: 'Goldway 6', price: 23000, dailyIncome: 1340, totalIncome: 54400 },
    { level: 'Goldway 7', price: 30000, dailyIncome: 1910, totalIncome: 305600 },
    { level: 'Gold VIP 1', price: 50000, dailyIncome: 3600, totalIncome: 576000 },
    { level: 'Gold VIP 2', price: 80000, dailyIncome: 5100, totalIncome: 816000 },
  ];

  document.addEventListener('DOMContentLoaded', () => {
    createInvestmentTable('vipTable', vipInvestments);
    createInvestmentTable('superLevTable', superLevInvestments);
    createInvestmentTable('goldWayTable', goldWayInvestments);
  });

  // Function to create investment tables
  function createInvestmentTable(tableId, data) {
    const table = document.getElementById(tableId);

    data.forEach(investment => {
      const row = table.insertRow();
      const keys = ['level', 'price', 'dailyIncome', 'totalIncome'];

      keys.forEach(key => {
        const cell = row.insertCell();
        cell.textContent = key === 'price' || key === 'dailyIncome' || key === 'totalIncome'
          ? formatCurrency(investment[key]) + ' Ksh'
          : investment[key];
      });

      const investButton = document.createElement('button');
      investButton.textContent = `Invest ${investment.level}`;
      investButton.addEventListener('click', () => showInvestmentDetails(investment));
      row.appendChild(investButton);
    });
  }


  
  // Function to confirm investment
  function confirmInvestment(investment) {
    const depositAmount = investment.price;
    const currentBalance = parseInt(document.getElementById('accountBalance').textContent);

    if (currentBalance >= depositAmount) {
      // Placeholder for backend API call
      // You would need to implement server-side logic to handle the investment confirmation

      // Simulate server response
      const confirmed = confirm(`Investment confirmed for ${investment.level}!`);
      
      if (confirmed) {
        // Decrease account balance
        decreaseAccountBalance(depositAmount);
        addToCart(investment.level, investment.price, investment.dailyIncome, investment.totalIncome);
      }
    } else {
      alert('Insufficient funds. Please deposit enough funds to complete the investment.');
    }

    resetCalculator();
  }

  // Function to deposit funds
  function deposit() {
    const depositAmountInput = document.getElementById('depositAmount');
    const depositAmount = parseInt(depositAmountInput.value);

    if (isNaN(depositAmount) || depositAmount <= 0) {
      alert('Please enter a valid deposit amount.');
      return;
    }

    // Placeholder for backend API call to update account balance
    // You need to implement server-side logic to update the account balance in the database
    // For simplicity, we'll simulate an update here
    const updatedBalance = simulateDeposit(depositAmount);

    // Update account balance on the front end
    document.getElementById('accountBalance').textContent = formatCurrency(updatedBalance);

    alert(`Deposit of ${formatCurrency(depositAmount)} Ksh successful!`);
    depositAmountInput.value = '';
  }

  // Simulate deposit for demo purposes
  function simulateDeposit(amount) {
    const currentBalance = parseInt(document.getElementById('accountBalance').textContent);
    return currentBalance + amount;
  }

  // Function to decrease account balance
  function decreaseAccountBalance(amount) {
    const accountBalance = document.getElementById('accountBalance');
    const updatedBalance = parseInt(accountBalance.textContent) - amount;
    accountBalance.textContent = formatCurrency(updatedBalance);
  }

  // Function to format currency
  function formatCurrency(amount) {
    return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES' }).format(amount);
  }

  // Function to show investment details
  function showInvestmentDetails(investment) {
    const calculator = document.getElementById('calculator');
    calculator.style.display = 'block';
    const calculatorContent = `Investing ${investment.level} - ${formatCurrency(investment.price)} Ksh`;
    calculator.textContent = calculatorContent;

    const investButton = document.createElement('button');
    investButton.textContent = 'Confirm Investment';
    investButton.addEventListener('click', () => confirmInvestment(investment));
    calculator.appendChild(investButton);
  }

  // Function to confirm investment
  function confirmInvestment(investment) {
    // Placeholder for backend API call
    // You would need to implement server-side logic to handle the investment confirmation
    alert(`Investment confirmed for ${investment.level}!`);
    resetCalculator();
  }

  // Function to reset the calculator
  function resetCalculator() {
    const calculator = document.getElementById('calculator');
    calculator.style.display = 'none';
    calculator.textContent = '';
  }

   // Function to add items to the cart
   function addToCart(level, price, dailyIncome, totalIncome) {
    const cartItems = document.getElementById('cartItems');
    const listItem = document.createElement('li');
    listItem.textContent = `${level}: ${formatCurrency(price)} Ksh (Daily: ${formatCurrency(dailyIncome)}, Total: ${formatCurrency(totalIncome)})`;
    cartItems.appendChild(listItem);

    // Update total investment
    const totalInvestment = document.getElementById('totalInvestment');
    const currentTotal = parseInt(totalInvestment.dataset.total) || 0;
    const newTotal = currentTotal + price;
    totalInvestment.textContent = `Total Investment: ${formatCurrency(newTotal)} Ksh`;
    totalInvestment.dataset.total = newTotal;

    // Decrease account balance
    decreaseAccountBalance(price);

    // Update progress bar
    updateProgressBar(newTotal);
  }

  // Function to update progress bar
  function updateProgressBar(totalInvestment) {
    const accountBalance = parseInt(document.getElementById('accountBalance').textContent);
    const progressPercentage = (totalInvestment / accountBalance) * 100;
    const progressBarFill = document.getElementById('progressBarFill');
    progressBarFill.style.width = `${Math.min(progressPercentage, 100)}%`;
  }
 

   // Function to add items to the cart
   function addToCart(level, price) {
    const cartItems = document.getElementById('cartItems');
    const listItem = document.createElement('li');
    listItem.textContent = `${level}: ${formatCurrency(price)} Ksh`;
    cartItems.appendChild(listItem);

    // Update total investment
    const totalInvestment = document.getElementById('totalInvestment');
    totalInvestment.textContent = formatCurrency(parseInt(totalInvestment.textContent) + price);

    // Decrease account balance
    decreaseAccountBalance(price);
  }