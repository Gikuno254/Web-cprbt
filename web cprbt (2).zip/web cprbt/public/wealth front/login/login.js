async function submitLogin(email, password) {
    try {
        const response = await fetch('/api/login/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        const result = await response.json();

        if (result.success) {
            alert('Login successful. Welcome to Goldway Wealth Investment Company!');
            // Redirect or perform necessary actions after successful login
        } else {
            displayErrorMessage(result.message);
        }
    } catch (error) {
        console.error('Submit login error:', error);
        displayErrorMessage('Internal server error.');
    }
}

 showLoadingMessage();

   // ... existing login logic

   // If login is successful, call the login function from auth.js
   login();

   hideLoadingMessage();

   // login.js
function login() {
    // ... your existing login logic ...

    // Set session variable on successful login
    sessionStorage.setItem('loggedInUser', 'user'); // Change this to the actual user identifier

    // Redirect to index.html or any other authenticated page
    window.location.href = '/index';
}
