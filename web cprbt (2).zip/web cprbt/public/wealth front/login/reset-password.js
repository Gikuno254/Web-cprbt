async function submitResetPassword(email) {
    try {
        const response = await fetch('/api/reset-password/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email }),
        });

        const result = await response.json();

        if (result.success) {
            alert('Password reset successful. Check your email for the new password.');
        } else {
            displayErrorMessage(result.message);
        }
    } catch (error) {
        console.error('Submit reset password error:', error);
        displayErrorMessage('Internal server error.');
    }
}
