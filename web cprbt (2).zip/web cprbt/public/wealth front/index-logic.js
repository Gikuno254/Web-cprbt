// index.js
document.addEventListener('DOMContentLoaded', function () {
    checkLoginStatus();
});

function checkLoginStatus() {
    const loggedInUser = localStorage.getItem('loggedInUser');

    if (loggedInUser) {
        const user = JSON.parse(loggedInUser);
        showWelcomeMessage(user.username);
    } else {
        showLoginPrompt();
    }
}

function showWelcomeMessage(username) {
    const welcomeMessage = document.getElementById('welcomeMessage');
    welcomeMessage.textContent = `Welcome, ${username}! You can now access the content.`;
}

function showLoginPrompt() {
    const loginPrompt = document.getElementById('loginPrompt');
    loginPrompt.style.display = 'block';
}
