function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";

        // Hide sidebar after 5 seconds
        setTimeout(() => {
                    hideSidebar();
                }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

    let testimonialIndex = 0;
    displayTestimonial();

    function displayTestimonial() {
        const testimonials = document.querySelectorAll('.testimonial');
        testimonials.forEach(testimonial => testimonial.style.display = 'none');
        
        testimonialIndex++;
        if (testimonialIndex > testimonials.length) {
            testimonialIndex = 1;
        }

        testimonials[testimonialIndex - 1].style.display = 'block';
        setTimeout(displayTestimonial, 5000); // Change testimonial every 5 seconds
    }
    document.addEventListener("DOMContentLoaded", function() {
    //get the button
    var scrollButton=document.querySelector(".scroll-to-top");
    //when the user scrolls down 20px from the top of the document, show the button
    window.onscroll=function(){
        scrollFunction();
    };
    function scrollFunction(){
        if (document.body.scrollTop>20 || document.documentElement.scrollTop>20){
            scrollButton.style.display="block";
        } else{
            scrollButton.style.display="none";
        }
    }
    //when the user clicksonthe button, scroll tothe topofthe document
    scrollButton.addEventListener("click", function(){
        document.body.scrollTop=0; // For Safari
        document.documentElement.scrollTop=0; // For Chrome, Firefox,IE, and Opera
    })
})

function sendMessage() {
    // You can add code here to handle the form submission
    alert('Message sent!'); // For demonstration purposes
}

// JavaScript for Customer Service Page

// Array to store customer messages
let customerMessages = [];

// Function to send a message
function sendMessage() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Validate input
    if (!name || !email || !message) {
        alert('Please fill in all fields.');
        return;
    }

    // Create a message object
    const newMessage = {
        name,
        email,
        message,
        timestamp: new Date().toLocaleString(),
    };

    // Add the message to the array
    customerMessages.push(newMessage);

    // Display the message in the live chat
    displayLiveChat(newMessage);

    // Display the message in customer testimonials
    displayTestimonial(newMessage);

    // Clear form fields
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('message').value = '';

    alert('Message sent!'); // For demonstration purposes
}

// Function to display a customer testimonial
function displayTestimonial(message) {
    const testimonialsContainer = document.getElementById('testimonialsContainer');
    const testimonialDiv = document.createElement('div');
    testimonialDiv.classList.add('testimonial');

    // Display customer name, message, and timestamp
    testimonialDiv.innerHTML = `
        <p>"${message.message}"</p>
        <p>- ${message.name} (${message.email}) - ${message.timestamp}</p>
    `;

    // Add the testimonial to the container
    testimonialsContainer.appendChild(testimonialDiv);
}

// Function to display a message in the live chat
function displayLiveChat(message) {
    const liveChatContainer = document.getElementById('liveChatContainer');
    const chatMessageDiv = document.createElement('div');
    chatMessageDiv.classList.add('chat-message');

    // Display customer name, message, and timestamp
    chatMessageDiv.innerHTML = `
        <p>${message.name} (${message.email}): ${message.message} - ${message.timestamp}</p>
    `;

    // Add the message to the live chat
    liveChatContainer.appendChild(chatMessageDiv);

    // Scroll to the bottom of the chat
    liveChatContainer.scrollTop = liveChatContainer.scrollHeight;
}

// Your existing JavaScript code

// Live Chat Functionality
function addChatMessage(sender, message) {
    const chatContainer = document.getElementById('liveChatContainer');
    const chatMessage = document.createElement('div');
    chatMessage.className = 'chat-message';
    chatMessage.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatContainer.appendChild(chatMessage);
    chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to the bottom of the chat
}

// Testimonials Data
const testimonialsData = [
    { message: 'Great customer service! The team was quick to respond and very helpful.', author: 'Happy Customer 1' },
    { message: 'I appreciate the excellent support. They went above and beyond my expectations.', author: 'Satisfied Customer 2' }
];

// Testimonials Functionality
let testimonialIndex = 0;

function displayTestimonials() {
    const testimonialsContainer = document.getElementById('testimonialsContainer');
    testimonialsContainer.innerHTML = ''; // Clear existing testimonials

    const testimonial = document.createElement('div');
    testimonial.className = 'testimonial';

    testimonial.innerHTML = `<p>"${testimonialsData[testimonialIndex].message}"</p>
                             <p>- ${testimonialsData[testimonialIndex].author}</p>`;

    testimonialsContainer.appendChild(testimonial);
    testimonialIndex = (testimonialIndex + 1) % testimonialsData.length;

    setTimeout(displayTestimonials, 5000); // Change testimonial every 5 seconds
}

// Add event listener for form submission
document.addEventListener('DOMContentLoaded', function() {
    // Your existing code

    // Start displaying testimonials
    displayTestimonials();
});

function sendMessage() {
    // Your existing code

    // Add live chat message to the container
    const sender = 'User'; // You can customize this based on your authentication system
    const message = document.getElementById('message').value; // Get the user's message
    addChatMessage(sender, message);

    // Clear the message input field
    document.getElementById('message').value = '';
}



/*firebase for real time updates*/
// Your existing JavaScript code

// Initialize Firebase - assuming you use Firebase for real-time updates
// You need to replace the Firebase configuration with your own
// Refer to Firebase documentation for setting up Firebase in your project
const firebaseConfig = {
    apiKey: 'your-api-key',
    authDomain: 'your-auth-domain',
    projectId: 'your-project-id',
    storageBucket: 'your-storage-bucket',
    messagingSenderId: 'your-messaging-sender-id',
    appId: 'your-app-id'
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Live Chat Functionality
function initializeLiveChat() {
    const liveChatContainer = document.getElementById('liveChatContainer');

    // Your logic to fetch and display chat messages from the database
    db.collection('chatMessages').onSnapshot(snapshot => {
        liveChatContainer.innerHTML = ''; // Clear existing messages

        snapshot.forEach(doc => {
            const message = doc.data();
            const messageElement = document.createElement('div');
            messageElement.innerHTML = `<strong>${message.sender}:</strong> ${message.text}`;
            liveChatContainer.appendChild(messageElement);
        });
    });
}

// Testimonials Functionality
function initializeTestimonials() {
    const testimonialsContainer = document.getElementById('testimonialsContainer');

    // Your logic to fetch and display testimonials from the database
    db.collection('testimonials').onSnapshot(snapshot => {
        testimonialsContainer.innerHTML = ''; // Clear existing testimonials

        snapshot.forEach(doc => {
            const testimonial = doc.data();
            const testimonialElement = document.createElement('div');
            testimonialElement.classList.add('testimonial');
            testimonialElement.innerHTML = `<p>"${testimonial.message}"</p><p>- ${testimonial.author}</p>`;
            testimonialsContainer.appendChild(testimonialElement);
        });
    });
}

// Your existing functions

// Ensure the DOM is fully loaded before initializing chat and testimonials
document.addEventListener('DOMContentLoaded', function () {
    initializeLiveChat();
    initializeTestimonials();
});

// Function to handle sending a new message
// Firebase configuration (replace with your own)
const firebaseConfig = {
    apiKey: 'YOUR_API_KEY',
    authDomain: 'YOUR_AUTH_DOMAIN',
    projectId: 'YOUR_PROJECT_ID',
    storageBucket: 'YOUR_STORAGE_BUCKET',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    appId: 'YOUR_APP_ID'
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Reference to the Firestore database
const db = firebase.firestore();

// Function to send a message to the Firestore database
function sendMessage() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Add the message to the 'messages' collection
    db.collection('messages').add({
        name: name,
        email: email,
        message: message,
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
    })
    .then(() => {
        alert('Message sent!');
        document.getElementById('contactForm').reset();
    })
    .catch(error => {
        console.error('Error sending message: ', error);
        alert('Error sending message. Please try again.');
    });
}

// Function to display messages in the live chat container
function displayLiveChat() {
    const liveChatContainer = document.getElementById('liveChatContainer');

    // Real-time listener for the 'messages' collection
    db.collection('messages')
        .orderBy('timestamp')
        .onSnapshot(snapshot => {
            liveChatContainer.innerHTML = ''; // Clear previous messages

            snapshot.forEach(doc => {
                const messageData = doc.data();
                const messageElement = document.createElement('div');
                messageElement.innerHTML = `<strong>${messageData.name}</strong>: ${messageData.message}`;
                liveChatContainer.appendChild(messageElement);
            });

            // Automatically scroll to the bottom of the live chat container
            liveChatContainer.scrollTop = liveChatContainer.scrollHeight;
        });
}

// Function to display testimonials
function displayTestimonials() {
    const testimonialsContainer = document.getElementById('testimonialsContainer');

    // Real-time listener for the 'testimonials' collection
    db.collection('testimonials')
        .orderBy('timestamp')
        .onSnapshot(snapshot => {
            testimonialsContainer.innerHTML = ''; // Clear previous testimonials

            snapshot.forEach(doc => {
                const testimonialData = doc.data();
                const testimonialElement = document.createElement('div');
                testimonialElement.innerHTML = `<p>"${testimonialData.message}"</p><p>- ${testimonialData.name}</p>`;
                testimonialsContainer.appendChild(testimonialElement);
            });
        });
}

// Initializations
document.addEventListener('DOMContentLoaded', () => {
    displayLiveChat(); // Display live chat messages
    displayTestimonials(); // Display testimonials
});



// Firebase Firestore setup
const db = firebase.firestore();

// Live Chat Functionality
const liveChatContainer = document.getElementById('liveChatContainer');
const chatForm = document.getElementById('contactForm');

chatForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const name = chatForm.name.value;
    const message = chatForm.message.value;

    if (name && message) {
        // Save message to Firebase Firestore
        db.collection('liveChat').add({
            name: name,
            message: message,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
        chatForm.reset();
    }
});

// Display live chat messages in real-time
db.collection('liveChat')
    .orderBy('timestamp')
    .onSnapshot(snapshot => {
        liveChatContainer.innerHTML = '';
        snapshot.forEach(doc => {
            const data = doc.data();
            const messageElement = document.createElement('p');
            messageElement.textContent = `${data.name}: ${data.message}`;
            liveChatContainer.appendChild(messageElement);
        });
    });

// Customer Testimonials Functionality
const testimonialsContainer = document.getElementById('testimonialsContainer');

// Display testimonials in real-time
db.collection('testimonials')
    .orderBy('timestamp', 'desc') // Show latest testimonials first
    .onSnapshot(snapshot => {
        testimonialsContainer.innerHTML = '';
        snapshot.forEach(doc => {
            const data = doc.data();
            const testimonialElement = document.createElement('div');
            testimonialElement.classList.add('testimonial');
            testimonialElement.innerHTML = `<p>"${data.message}"</p><p>- ${data.name}</p>`;
            testimonialsContainer.appendChild(testimonialElement);
        });
    });

// Add your existing scripts (toggleSidebar, scroll-to-top, etc.) here
// Ensure the existing scripts are placed after the Firebase and live chat scripts


// customer_service.js

// Function to send live chat message



// customer_service.js

// Function to send live chat message
// Function to send live chat message
function sendMessage() {
    const name = document.getElementById('name').value;
    const message = document.getElementById('message').value;

    if (name && message) {
        // Send message to backend
        fetch('/api/livechat/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: name,
                message: message
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Message sent:', data);
            // After sending the message, update the live chat messages
            getLiveChatMessages();
        })
        .catch(error => {
            console.error('Error sending message:', error);
        });

        // Clear input fields
        document.getElementById('name').value = '';
        document.getElementById('message').value = '';
    }
}

// Function to retrieve live chat messages
function getLiveChatMessages() {
    // Fetch messages from backend
    fetch('/api/livechat/messages')
        .then(response => response.json())
        .then(messages => {
            // Update frontend with messages
            const liveChatContainer = document.getElementById('liveChatContainer');
            liveChatContainer.innerHTML = messages.map(message => `<p>${message.name}: ${message.message}</p>`).join('');
        })
        .catch(error => {
            console.error('Error getting live chat messages:', error);
        });
}

// Function to add testimonial
function addTestimonial() {
    const testimonialName = document.getElementById('testimonialName').value;
    const testimonialMessage = document.getElementById('testimonialMessage').value;

    if (testimonialName && testimonialMessage) {
        // Add testimonial to backend
        fetch('/api/testimonials', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: testimonialName,
                message: testimonialMessage
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Testimonial added:', data);
            // After adding the testimonial, update the testimonials
            getTestimonials();
        })
        .catch(error => {
            console.error('Error adding testimonial:', error);
        });

        // Clear input fields
        document.getElementById('testimonialName').value = '';
        document.getElementById('testimonialMessage').value = '';
    }
}

// Function to retrieve testimonials
function getTestimonials() {
    // Fetch testimonials from backend
    fetch('/api/testimonials')
        .then(response => response.json())
        .then(testimonials => {
            // Update frontend with testimonials
            const testimonialsContainer = document.getElementById('testimonialsContainer');
            testimonialsContainer.innerHTML = testimonials.map(testimonial => `<div class="testimonial"><p>"${testimonial.message}"</p><p>- ${testimonial.name}</p></div>`).join('');
        })
        .catch(error => {
            console.error('Error getting testimonials:', error);
        });
}
