// index.js
function checkLoginStatus() {
    const loggedInUser = localStorage.getItem('loggedInUser');

    if (loggedInUser) {
        // User is logged in, show content
        showLoggedInContent();
    } else {
        // User is not logged in, show login prompt
        showLoginPrompt();
    }
}

function showLoggedInContent() {
    // Display the content that should be visible to logged-in users
    document.getElementById('welcomeMessage').style.display = 'block';
    document.getElementById('logoutButton').style.display = 'block';
    document.getElementById('loginPrompt').style.display = 'none';
}

function showLoginPrompt() {
    // Display the login prompt for users who are not logged in
    document.getElementById('welcomeMessage').style.display = 'none';
    document.getElementById('logoutButton').style.display = 'none';
    document.getElementById('loginPrompt').style.display = 'block';
}

function logout() {
    // Call the logout function from auth.js and update UI
    logout();
    showLoginPrompt();
}
