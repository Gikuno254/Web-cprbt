function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";

        // Hide sidebar after 5 seconds
        setTimeout(() => {
                    hideSidebar();
                }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

    function validateForm() {
        var name = document.getElementById('name').value;
        var amount = document.getElementById('amount').value;

        if (name.trim() === '') {
            alert('Please enter your first and last name.');
            return false;
        }

        if (isNaN(amount) || amount <= 0) {
            alert('Please enter a valid amount.');
            return false;
        }

        return true;
    }
    function confirmSubmission() {
                if (validateForm()) {
                    return confirm('Are you sure you want to submit the form?');
                }

                return false;
            }

            // Responsive adjustments for smaller screens
            function adjustForSmallScreens() {
                var amountInput = document.getElementById('amount');
                var amountGroup = amountInput.parentNode;

                if (window.innerWidth <= 600) {
                    amountInput.style.width = '100%';
                    amountGroup.style.flexDirection = 'column';
                } else {
                    amountInput.style.width = '';
                    amountGroup.style.flexDirection = 'row';
                }
            }

            // Adjust on page load and on window resize
            window.onload = adjustForSmallScreens;
            window.onresize = adjustForSmallScreens;


            // generate token and value automatically
    const generateTokenAndValue = async () => {
      try {
        const response = await fetch('http://localhost:3000/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            // You can include any additional data in the request body if needed
          })
        });

        if (!response.ok) {
          throw new Error('Failed to generate token and value');
        }

        const data = await response.json();
        const { token, value } = data;

        // Use the generated token and value as needed
        console.log('Generated Token:', token);
        console.log('Generated Value:', value);

      } catch (error) {
        console.error(error.message);
      }
    };