function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");


     function openSidebar()  {
        document.getElementById("mySidebar").style.with="250px";
        document.body.style.marginLeft="250px";
     }
    

     function closeSidebar() {
        document.getElementById("mySidebar").style.width="0";
        document.body.style.marginLeft="0";
     }


    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";

        // Hide sidebar after 5 seconds
        setTimeout(() => {
                    hideSidebar();
                }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

function calculateReturns() {
    var additionalInvestment = parseFloat(document.getElementById("investment-amount").value);
    var currentInvestment = 500000; // Assuming current investment is 500,000 KSH
    var expectedReturnsRate = 0.05; // 5% per annum

    var totalInvestment = currentInvestment + additionalInvestment;
    var returns = totalInvestment * expectedReturnsRate;

    alert("Your total investment returns: " + returns.toFixed(2) + " KSH");
}

function chooseFile() {
    document.getElementById('file-input').click();
}

// Function to handle file input change
document.getElementById('file-input').addEventListener('change', function (e) {
    var fileInput = e.target;
    var profilePicture = document.getElementById('profile-picture');

    // Assuming you have a function to handle image preview
    // You may need to implement the logic for handling file uploads on the server side
    previewImage(fileInput, profilePicture);
});

// Placeholder function for image preview
function previewImage(fileInput, imageElement) {
    var file = fileInput.files[0];

    if (file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            imageElement.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}






// Additional scripts for enhanced functionality
function changePassword() {
    // Prompt user for email
    const userEmail = prompt('Please enter your email for confirmation:');
    
    // Simulate email confirmation (replace with actual email sending logic)
    if (userEmail) {
        const confirmationCode = generateConfirmationCode(); // Function to generate a unique code
        const confirmationLink = `https://example.com/confirm?code=${confirmationCode}`;

        alert(`An email with confirmation link has been sent to ${userEmail}. Please click the link to confirm.`);

        // Simulate email sending (replace with actual email sending logic)
        sendEmail(userEmail, `Confirmation Link: ${confirmationLink}`);
    } else {
        alert('Email confirmation canceled. Password not changed.');
    }
}

// Simulated function to generate a unique confirmation code
function generateConfirmationCode() {
    return Math.random().toString(36).substring(2, 10);
}

// Simulated function to send email (replace with actual email sending logic)
function sendEmail(email, content) {
    console.log(`Email sent to ${email} with content: ${content}`);
}

// Function to handle confirmation link click
function handleConfirmationLinkClick() {
    const newPassword = prompt('Please enter your new password:');
    if (newPassword) {
        alert('Password changed successfully!');
    } else {
        alert('Password change canceled.');
    }
}


// profile.js

// Function to fetch user profile details


// profile.js
document.addEventListener('DOMContentLoaded', function () {
    // Fetch user profile details on page load
    fetchUserProfile();
  
    // Function to fetch user profile details
    function fetchUserProfile() {
      fetch('/api/profile')
        .then(response => response.json())
        .then(profile => {
          // Update the UI with user profile details
          updateProfileUI(profile);
        })
        .catch(error => console.error('Error fetching user profile:', error));
    }
  
    // Function to update the UI with user profile details
    function updateProfileUI(profile) {
      const nameElement = document.getElementById('user-name');
      const emailElement = document.getElementById('user-email');
      // Add other elements as needed
  
      // Update UI elements with profile details
      nameElement.textContent = `Name: ${profile.name}`;
      emailElement.textContent = `Email: ${profile.email}`;
      // Update other elements
  
      // You can add logic to handle profile picture, investment details, etc.
    }
  
    // Event listener for the "Change Password" button
    function changePassword() {
      // Implement password change functionality if needed
      alert('Change Password functionality coming soon!');
    }
  });
  