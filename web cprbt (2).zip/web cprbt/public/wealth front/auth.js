// Simple authentication using local storage (not secure for real-world use)
function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Check if user exists in local storage
    const storedUser = localStorage.getItem(username);
    if (storedUser && JSON.parse(storedUser).password === password) {
        alert('Login successful!');
    } else {
        alert('Invalid username or password');
    }
}

function register() {
    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    // Check if user already exists in local storage
    if (localStorage.getItem(newUsername)) {
        alert('Username already exists. Please choose another username.');
    } else {
        // Store new user in local storage
        const newUser = { username: newUsername, password: newPassword };
        localStorage.setItem(newUsername, JSON.stringify(newUser));
        alert('Registration successful!');
    }
}



    // If login is successful, store the user in local storage
    localStorage.setItem('loggedInUser', JSON.stringify({ username }));
    showWelcomeMessage(username);


function logout() {
    // Clear the logged-in user when logging out
    localStorage.removeItem('loggedInUser');
}