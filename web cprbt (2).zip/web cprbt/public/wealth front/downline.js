function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";

        // Hide sidebar after 5 seconds
        setTimeout(() => {
                    hideSidebar();
                }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

        function referFriend() {
            // Get values from the form
            var friendName = document.getElementById('friendName').value;
            var friendEmail = document.getElementById('friendEmail').value;

            // Calculate bonuses
            var clientBonus = 5;
            var referredFriendBonus = 3;
            var client2Bonus = 2;

            // Display bonuses
            alert(`Congratulations!\nYou earned Ksh ${clientBonus} for referring ${friendName}.\n${friendName} earned Ksh ${referredFriendBonus}.\nClient 2 earned Ksh ${client2Bonus}.`);
        }