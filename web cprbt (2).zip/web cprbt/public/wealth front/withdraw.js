 
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        const body = document.body;
        const overlay = document.getElementById("overlay");
    
        if (sidebar.style.width === "250px") {
            hideSidebar();
        } else {
            sidebar.style.width = "250px";
            body.classList.add("sidebar-open");
            overlay.style.display = "block";
    
            // Hide sidebar after 5 seconds
            setTimeout(() => {
                        hideSidebar();
                    }, 5000);
        }
    }
    
    function hideSidebar() {
        const sidebar = document.getElementById("sidebar");
        const body = document.body;
        const overlay = document.getElementById("overlay");
    
        sidebar.style.width = "0";
        body.classList.remove("sidebar-open");
        overlay.style.display = "none";
    }
    
        document.addEventListener("DOMContentLoaded", function() {
            // Add your initialization logic here if needed
        });
    
        function withdrawMoney() {
            // Add logic for withdrawing money here
            // Access form data using JavaScript, validate inputs, make API requests, etc.
            // For example, you can access the data using:
            // const isCrypto = document.querySelector('[name="isCrypto"]').value;
            // const walletType = document.querySelector('[name="wallet"]:checked').value;
            // const phoneNumber = document.querySelector('[name="address"]').value;
            // const withdrawalAmount = document.querySelector('[name="amount"]').value;
            // ...
    
            // Prevent the form from submitting if needed
            // e.g., return false; or use @submit.prevent in the form tag
        }