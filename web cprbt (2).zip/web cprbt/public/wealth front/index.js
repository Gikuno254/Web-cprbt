function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    if (sidebar.style.width === "250px") {
        hideSidebar();
    } else {
        sidebar.style.width = "250px";
        body.classList.add("sidebar-open");
        overlay.style.display = "block";
       
       
        // Hide sidebar after 5 seconds
        setTimeout(() => {
                hideSidebar();
            }, 5000);
    }
}

function hideSidebar() {
    const sidebar = document.getElementById("sidebar");
    const body = document.body;
    const overlay = document.getElementById("overlay");

    sidebar.style.width = "0";
    body.classList.remove("sidebar-open");
    overlay.style.display = "none";
}

document.addEventListener("DOMContentLoaded", function() {
    //get the button
    var scrollButton=document.querySelector(".scroll-to-top");
    //when the user scrolls down 20px from the top of the document, show the button
    window.onscroll=function(){
        scrollFunction();
    };
    function scrollFunction(){
        if (document.body.scrollTop>20 || document.documentElement.scrollTop>20){
            scrollButton.style.display="block";
        } else{
            scrollButton.style.display="none";
        }
    }
    //when the user clicksonthe button, scroll tothe topofthe document
    scrollButton.addEventListener("click", function(){
        document.body.scrollTop=0; // For Safari
        document.documentElement.scrollTop=0; // For Chrome, Firefox,IE, and Opera
    })
})

// Add this script in your index.js file
function toggleMobileMenu() {
    const mobileMenu = document.getElementById("mobileMenu");
    mobileMenu.classList.toggle("show");
}

  // Wallet Balance
  let walletBalance = 0; // Initial balance is set to 0, customers start with no money

// Update wallet balance based on financial activities
function updateWallet(amount) {
    walletBalance += amount;
    document.getElementById('walletBalance').innerText = `KSH ${walletBalance}`;
}

// Deposit Functionality
function deposit(amount) {
    updateWallet(amount);
}

// Withdraw Functionality
function withdraw(amount) {
    if (walletBalance >= amount) {
        updateWallet(-amount);
    } else {
        alert('Insufficient funds in the account.');
    }
}

// Invest Functionality
function invest(amount) {
    if (walletBalance >= amount) {
        updateWallet(-amount);
        // Additional logic for investments (e.g., record the investment, calculate daily income, etc.)
        // ...
        alert('Investment successful!');
    } else {
        alert('Insufficient funds in the account.');
    }
}

// Daily Income Functionality (example: increase wallet balance by a fixed amount for each level of investment)
function calculateDailyIncome(level) {
    // Example: $10 daily income for each level of investment
    const dailyIncome = 10;
    updateWallet(dailyIncome * level);
}

// ... (existing JavaScript code)

function navigateTo(page) {
    switch (page) {
        case 'accountBalance':
            updateWallet(0); // No change in balance for account balance
            window.location.href = 'account_balance.html'; // Replace with your actual file name
            break;
        case 'transactionHistory':
            updateWallet(0); // No change in balance for transaction history
            window.location.href = 'transaction_history.html'; // Replace with your actual file name
            break;
        case 'withdrawHistory':
            withdraw(500); // Example: withdraw KSH 500
            window.location.href = 'withdraw_history.html'; // Replace with your actual file name
            break;
        case 'investmentHistory':
            invest(1000); // Example: invest KSH 1000
            calculateDailyIncome(2); // Example: calculate daily income for level 2 investment
            window.location.href = 'investment_history.html'; // Replace with your actual file name
            break;
        default:
            break;
    }
}


// JavaScript for Wallet Container
document.getElementById('walletContainer').addEventListener('click', function() {
    // Redirect to the investment page
    window.location.href = 'investment.html';
});

// Assume there's a button to initiate a transaction
document.getElementById('transactionBtn').addEventListener('click', function() {
    // Check if the user has enough balance for the transaction
    var userBalance = parseFloat(document.getElementById('walletBalance').innerText.replace('KSH ', ''));
    
    // Simulate a transaction
    if (userBalance >= transactionAmount) {
        // Perform the transaction logic here (e.g., deduct the amount, update transaction history, etc.)
        alert('Transaction successful!');
    } else {
        alert('Insufficient funds!');
    }
});

// JavaScript for Account Balance Container
document.getElementById('accountBalance').addEventListener('click', function() {
    // Display options/modal for account balance actions (withdraw, deposit, send, invest)
    // Redirect to the respective pages or trigger the related actions
    alert('Account Balance Clicked!');
});


// JavaScript for Investment History Container
document.getElementById('exploreHistoryBtn').addEventListener('click', function() {
    // Redirect to the invest page or display a modal with investment history details
    alert('Explore Investment History Clicked!');
});


// JavaScript for Daily Income Container
document.getElementById('trackIncomeBtn').addEventListener('click', function() {
    // Redirect to the invest page or display a modal with daily income details
    alert('Track Daily Income Clicked!');
});

 // Placeholder for simulating account balance (set to 0 initially)
 let accountBalance = 0;

 // Update account balance display
 function updateAccountBalanceDisplay() {
     document.getElementById('accountBalanceAmount').innerText = `KSH ${accountBalance}`;
 }

 // Function to check if the account balance is sufficient for a transaction
 function isBalanceSufficient(amount) {
     return accountBalance >= amount;
 }

 // Event listener for initiating transactions
 document.getElementById('transactionBtn').addEventListener('click', function() {
     // Placeholder for transaction logic
     const transactionAmount = 100; // Replace with the actual amount
     if (isBalanceSufficient(transactionAmount)) {
         // Perform the transaction logic here (e.g., deduct the amount, update transaction history, etc.)
         accountBalance -= transactionAmount;
         updateAccountBalanceDisplay();
         alert('Transaction successful!');
     } else {
         alert('Insufficient funds!');
     }
 });

 // Event listener for deposit button
 document.getElementById('depositBtn').addEventListener('click', function() {
     // Placeholder for deposit logic
     const depositAmount = 200; // Replace with the actual amount
     accountBalance += depositAmount;
     updateAccountBalanceDisplay();
     alert('Deposit successful!');
 });

 // Event listener for exploring investment history
 document.getElementById('exploreHistoryBtn').addEventListener('click', function() {
     // Placeholder for displaying investment history details
     document.getElementById('investmentHistoryDetails').style.display = 'block';
     // Retrieve and display investment history details
 });

 // Event listener for tracking daily income
 document.getElementById('trackIncomeBtn').addEventListener('click', function() {
     // Placeholder for displaying daily income details
     document.getElementById('dailyIncomeDetails').style.display = 'block';
     // Retrieve and display daily income details
 });

 // auth.js or logout.js
function logout() {
    // ... your existing logout logic ...

    // Clear session variable on logout
    sessionStorage.removeItem('loggedInUser');

    // Redirect to login page
    window.location.href = '/login';
}
