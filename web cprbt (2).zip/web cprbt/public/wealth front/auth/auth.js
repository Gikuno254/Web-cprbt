// auth.js
function login() {
    // ... existing login logic

    // If login is successful, store the user in local storage
    localStorage.setItem('loggedInUser', JSON.stringify({ username }));
    showWelcomeMessage(username);
}

function logout() {
    // Clear the logged-in user when logging out
    localStorage.removeItem('loggedInUser');
    showLoginPrompt();
}

function checkLoginStatus() {
    const loggedInUser = localStorage.getItem('loggedInUser');

    if (loggedInUser) {
        const user = JSON.parse(loggedInUser);
        showWelcomeMessage(user.username);
    } else {
        showLoginPrompt();
    }
}
