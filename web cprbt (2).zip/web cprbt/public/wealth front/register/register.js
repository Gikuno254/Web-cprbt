function submitForm(firstName, secondName, email, phoneNumber, password) {
    // ... (previous code)

    // If all validations pass, submit the form (you can replace this with your actual submission logic)
    submitToBackend(firstName, secondName, email, phoneNumber, password);
}

async function submitToBackend(firstName, secondName, email, phoneNumber, password) {
    try {
        const response = await fetch('/api/registration/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                firstName,
                secondName,
                email,
                phoneNumber,
                password,
            }),
        });

        const result = await response.json();
        
        if (result.success) {
            alert('Registration successful. Check your email for verification.');
            window.location.href = '/login/login.html'; // Redirect to login page
        } else {
            displayErrorMessage(result.message);
        }
    } catch (error) {
        console.error('Submit to backend error:', error);
        displayErrorMessage('Internal server error.');
    }
}

 showLoadingMessage();

   // ... existing registration logic

   // If registration is successful, call the login function from auth.js
   login();

   hideLoadingMessage();
